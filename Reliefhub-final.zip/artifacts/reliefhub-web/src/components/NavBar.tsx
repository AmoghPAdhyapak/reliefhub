import { useState, useRef, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Shield, FlaskConical, Radar, Globe, Zap, ChevronDown, Home } from "lucide-react";
import { useLanguage, LANGUAGES } from "../context/LanguageContext";

export default function NavBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t, lang, langDef, setLang } = useLanguage();
  const [langOpen, setLangOpen] = useState(false);
  const dropRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setLangOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const links = [
    { to: "/", label: t("nav_dashboard"), icon: <Shield size={13} />, exact: true },
    { to: "/testing", label: t("nav_simulation"), icon: <FlaskConical size={13} />, exact: false },
    { to: "/radar", label: t("nav_radar"), icon: <Radar size={13} />, exact: false },
  ];

  function isActive(to: string, exact: boolean) {
    if (exact) return location.pathname === to || location.pathname === "/dashboard";
    return location.pathname.startsWith(to);
  }

  return (
    <nav className="bg-white border-b border-[hsl(214,32%,91%)] px-3 sm:px-4 py-2 flex items-center gap-2 sticky top-0 z-[5000] shadow-sm">
      {/* ── Left: Language selector ──────────────────────────── */}
      <div className="relative" ref={dropRef}>
        <button
          onClick={() => setLangOpen(!langOpen)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[hsl(214,32%,91%)] text-[10px] font-semibold text-[hsl(215,16%,47%)] hover:bg-[hsl(210,40%,96%)] transition-colors"
        >
          <Globe size={12} className="text-[hsl(142,76%,36%)]" />
          <span className="hidden xs:inline font-bold text-[hsl(222,47%,11%)]" dir={langDef.dir || "ltr"}>{langDef.native}</span>
          <ChevronDown size={10} className={`transition-transform ${langOpen ? "rotate-180" : ""}`} />
        </button>

        {langOpen && (
          <div className="absolute top-full left-0 mt-1 w-64 bg-white border border-[hsl(214,32%,91%)] rounded-xl shadow-xl z-[9000] py-2 max-h-72 overflow-y-auto animate-fade-in">
            <div className="px-3 py-1.5 text-[9px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider border-b border-[hsl(214,32%,91%)] mb-1">
              Select Language
            </div>
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => { setLang(l.code); setLangOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-[hsl(210,40%,96%)] transition-colors text-left ${
                  lang === l.code ? "bg-[hsl(142,76%,96%)] text-[hsl(142,76%,28%)]" : "text-[hsl(222,47%,11%)]"
                }`}
                dir={l.dir || "ltr"}
              >
                <span className="text-base font-bold w-20 shrink-0">{l.native}</span>
                <span className="text-[10px] text-[hsl(215,16%,47%)]">{l.name}</span>
                {lang === l.code && <span className="ml-auto text-[9px] font-bold text-[hsl(142,76%,36%)]">✓</span>}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Center: Logo + Nav Links ──────────────────────────── */}
      <div className="flex items-center gap-1 flex-1 overflow-x-auto scrollbar-none">
        <Link to="/" className="flex items-center gap-1.5 mr-2 shrink-0">
          <div className="bg-[hsl(142,76%,93%)] p-1 rounded-md">
            <svg width="14" height="14" viewBox="0 0 96 96" fill="none"><path d="M48 4L12 20V48C12 67.2 28 83.6 48 92C68 83.6 84 67.2 84 48V20L48 4Z" fill="hsl(142,76%,36%)" /><text x="48" y="58" textAnchor="middle" fill="white" fontSize="32" fontWeight="800" fontFamily="system-ui">RH</text></svg>
          </div>
          <span className="text-xs font-black text-[hsl(222,47%,11%)] tracking-wide hidden sm:block">RELIEFHUB</span>
        </Link>

        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 ${
              isActive(link.to, link.exact)
                ? "bg-[hsl(222,47%,11%)] text-white"
                : "text-[hsl(215,16%,47%)] hover:bg-[hsl(210,40%,96%)] hover:text-[hsl(222,47%,11%)]"
            }`}
          >
            {link.icon}
            <span className="hidden sm:inline">{link.label}</span>
          </Link>
        ))}

        <Link
          to="/help"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 ${
            location.pathname === "/help"
              ? "bg-red-600 text-white"
              : "text-red-600 border border-red-200 hover:bg-red-50"
          }`}
        >
          <Zap size={13} className="shrink-0" />
          <span className="hidden sm:inline">{t("nav_help")}</span>
        </Link>
      </div>

      {/* ── Right: View Live Demo + Status ───────────────────── */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => navigate("/testing")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[hsl(238,83%,57%)] hover:opacity-90 text-white text-[10px] font-bold transition-all whitespace-nowrap"
        >
          <Zap size={11} />
          <span className="hidden sm:inline">{t("btn_view_demo")}</span>
          <span className="sm:hidden">Demo</span>
        </button>
        <div className="hidden md:flex items-center gap-1.5 bg-[hsl(142,76%,93%)] px-2 py-1 rounded-full">
          <div className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
          <span className="text-[9px] font-semibold text-[hsl(142,76%,30%)]">{t("system_online")}</span>
        </div>
      </div>
    </nav>
  );
}
