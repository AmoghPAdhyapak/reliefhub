import { useState, useEffect } from "react";
import {
  Cloud, Wind, Thermometer, Droplets, AlertTriangle, Activity,
  RefreshCw, MapPin, Radio, Zap
} from "lucide-react";

interface WeatherData {
  rainfall_mm: number;
  wind_speed_kmh: number;
  temperature_c: number;
  wind_gusts_kmh: number;
  flood_risk: "Low" | "Moderate" | "High" | "Extreme";
  storm_intensity: "Calm" | "Moderate" | "Severe" | "Extreme";
  weather_alert: string;
  alert_level: "green" | "yellow" | "orange" | "red";
  fetched_at: string;
}

const MOCK_DATA: WeatherData = {
  rainfall_mm: 87.4,
  wind_speed_kmh: 64,
  temperature_c: 32.1,
  wind_gusts_kmh: 112,
  flood_risk: "High",
  storm_intensity: "Severe",
  weather_alert: "Active Cyclonic Storm Warning — Coastal areas on high alert. Evacuations recommended.",
  alert_level: "orange",
  fetched_at: new Date().toLocaleString(),
};

function deriveInsights(data: {
  precipitation_sum: number;
  windspeed_10m_max: number;
  temperature_2m_max: number;
  windgusts_10m_max: number;
}): WeatherData {
  const rain = data.precipitation_sum;
  const wind = data.windspeed_10m_max;
  const gusts = data.windgusts_10m_max;
  const temp = data.temperature_2m_max;

  const floodRisk: WeatherData["flood_risk"] =
    rain > 100 ? "Extreme" : rain > 50 ? "High" : rain > 20 ? "Moderate" : "Low";

  const stormIntensity: WeatherData["storm_intensity"] =
    gusts > 120 ? "Extreme" : gusts > 80 ? "Severe" : gusts > 40 ? "Moderate" : "Calm";

  let alertLevel: WeatherData["alert_level"] = "green";
  let alertMsg = "No significant weather alerts. Conditions nominal.";

  if (rain > 80 || gusts > 100) {
    alertLevel = "red";
    alertMsg = "⚠ Extreme Weather Alert — Immediate evacuation recommended for low-lying areas.";
  } else if (rain > 40 || gusts > 70) {
    alertLevel = "orange";
    alertMsg = "Active Storm Warning — Coastal and riverside areas on high alert.";
  } else if (rain > 15 || gusts > 40) {
    alertLevel = "yellow";
    alertMsg = "Weather Watch — Monitor conditions. Pre-position relief supplies.";
  }

  return {
    rainfall_mm: rain,
    wind_speed_kmh: wind,
    temperature_c: temp,
    wind_gusts_kmh: gusts,
    flood_risk: floodRisk,
    storm_intensity: stormIntensity,
    weather_alert: alertMsg,
    alert_level: alertLevel,
    fetched_at: new Date().toLocaleString(),
  };
}

interface WeatherCardProps {
  label: string;
  value: string;
  unit?: string;
  icon: React.ReactNode;
  accent: string;
  subtext?: string;
  badge?: { text: string; color: string };
}

function WeatherCard({ label, value, unit, icon, accent, subtext, badge }: WeatherCardProps) {
  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-[hsl(215,16%,47%)] uppercase tracking-wider">{label}</span>
        <div className={`p-2 rounded-lg ${accent}`}>{icon}</div>
      </div>
      <div className="flex items-baseline gap-1">
        <div className="text-3xl font-bold text-[hsl(222,47%,11%)]">{value}</div>
        {unit && <div className="text-sm text-[hsl(215,16%,47%)] font-medium">{unit}</div>}
      </div>
      {badge && (
        <div className={`mt-2 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${badge.color}`}>
          {badge.text}
        </div>
      )}
      {subtext && <div className="text-[10px] text-[hsl(215,16%,47%)] mt-1">{subtext}</div>}
    </div>
  );
}

export default function RadarPage() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usingMock, setUsingMock] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<string>("");

  async function fetchWeather() {
    setLoading(true);
    setError(null);
    try {
      const url =
        "https://api.open-meteo.com/v1/forecast?latitude=20.0&longitude=78.5" +
        "&daily=temperature_2m_max,precipitation_sum,windspeed_10m_max,windgusts_10m_max" +
        "&timezone=Asia%2FKolkata&forecast_days=1";
      const resp = await fetch(url, { signal: AbortSignal.timeout(8000) });
      if (!resp.ok) throw new Error("API error");
      const data = await resp.json();
      const daily = data.daily;
      const insights = deriveInsights({
        precipitation_sum: daily.precipitation_sum?.[0] ?? 0,
        windspeed_10m_max: daily.windspeed_10m_max?.[0] ?? 0,
        temperature_2m_max: daily.temperature_2m_max?.[0] ?? 30,
        windgusts_10m_max: daily.windgusts_10m_max?.[0] ?? 0,
      });
      setWeather(insights);
      setUsingMock(false);
    } catch {
      setWeather({ ...MOCK_DATA, fetched_at: new Date().toLocaleString() });
      setUsingMock(true);
    } finally {
      setLoading(false);
      setLastRefresh(new Date().toLocaleTimeString());
    }
  }

  useEffect(() => {
    fetchWeather();
  }, []);

  const alertColors = {
    green: "bg-emerald-50 border-emerald-300 text-emerald-800",
    yellow: "bg-amber-50 border-amber-300 text-amber-800",
    orange: "bg-orange-50 border-orange-300 text-orange-800",
    red: "bg-red-50 border-red-300 text-red-800",
  };

  const alertIconColors = {
    green: "text-emerald-600",
    yellow: "text-amber-600",
    orange: "text-orange-600",
    red: "text-red-600",
  };

  const floodColors: Record<string, string> = {
    Low: "bg-emerald-100 text-emerald-700",
    Moderate: "bg-amber-100 text-amber-700",
    High: "bg-orange-100 text-orange-700",
    Extreme: "bg-red-100 text-red-700",
  };

  const stormColors: Record<string, string> = {
    Calm: "bg-emerald-100 text-emerald-700",
    Moderate: "bg-amber-100 text-amber-700",
    Severe: "bg-orange-100 text-orange-700",
    Extreme: "bg-red-100 text-red-700",
  };

  return (
    <div className="min-h-screen bg-[hsl(210,40%,98%)] p-4 lg:p-6 flex flex-col gap-4">
      {/* Header */}
      <header className="bg-white border border-[hsl(214,32%,91%)] px-5 py-4 rounded-2xl shadow-sm flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-2.5 rounded-xl">
            <Radio size={22} className="text-blue-600" />
          </div>
          <div>
            <div className="text-lg font-bold text-[hsl(222,47%,11%)] tracking-tight">Radar Portal</div>
            <div className="text-[11px] text-[hsl(215,16%,47%)]">
              Live Weather Intelligence — Central India Disaster Zone (20°N, 78.5°E)
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {usingMock && (
            <div className="bg-amber-50 border border-amber-200 text-amber-700 text-[10px] font-semibold px-3 py-1 rounded-full">
              Scenario Data Active
            </div>
          )}
          <button
            onClick={fetchWeather}
            disabled={loading}
            className="flex items-center gap-1.5 bg-[hsl(222,47%,11%)] text-white text-xs font-semibold px-3 py-2 rounded-lg hover:bg-[hsl(222,47%,8%)] transition-colors disabled:opacity-50"
          >
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
            Refresh
          </button>
        </div>
      </header>

      {/* Data Source Note */}
      <div className="flex items-center gap-2 bg-white border border-[hsl(214,32%,91%)] rounded-xl px-4 py-2.5 text-[11px] text-[hsl(215,16%,47%)]">
        <MapPin size={12} className="text-blue-500 shrink-0" />
        <span>
          <strong className="text-[hsl(222,47%,11%)]">Data Source:</strong>{" "}
          {usingMock ? "Scenario mock data (Open-Meteo unavailable)" : "Open-Meteo API — Real-time forecast data"}
          {lastRefresh && ` · Last refreshed: ${lastRefresh}`}
        </span>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-10 h-10 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-3" />
            <div className="text-sm text-[hsl(215,16%,47%)]">Fetching weather data...</div>
          </div>
        </div>
      ) : weather ? (
        <>
          {/* Alert Banner */}
          <div className={`border rounded-xl px-5 py-4 flex items-start gap-3 ${alertColors[weather.alert_level]}`}>
            <AlertTriangle size={18} className={`shrink-0 mt-0.5 ${alertIconColors[weather.alert_level]}`} />
            <div>
              <div className="text-sm font-bold mb-0.5">
                Weather Alert — {weather.alert_level === "green" ? "All Clear" : weather.alert_level === "yellow" ? "Watch" : weather.alert_level === "orange" ? "Warning" : "Emergency"}
              </div>
              <div className="text-xs leading-relaxed">{weather.weather_alert}</div>
            </div>
          </div>

          {/* Weather Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            <WeatherCard
              label="Rainfall"
              value={weather.rainfall_mm.toFixed(1)}
              unit="mm"
              icon={<Droplets size={16} className="text-blue-600" />}
              accent="bg-blue-100"
              subtext="24-hour precipitation total"
              badge={
                weather.rainfall_mm > 60
                  ? { text: "Heavy Rain", color: "bg-blue-100 text-blue-700" }
                  : { text: "Light Rain", color: "bg-sky-100 text-sky-700" }
              }
            />
            <WeatherCard
              label="Wind Speed"
              value={weather.wind_speed_kmh.toFixed(0)}
              unit="km/h"
              icon={<Wind size={16} className="text-violet-600" />}
              accent="bg-violet-100"
              subtext="10m sustained wind speed"
            />
            <WeatherCard
              label="Temperature"
              value={weather.temperature_c.toFixed(1)}
              unit="°C"
              icon={<Thermometer size={16} className="text-orange-600" />}
              accent="bg-orange-100"
              subtext="Maximum daily temperature"
            />
            <WeatherCard
              label="Flood Risk"
              value={weather.flood_risk}
              icon={<Activity size={16} className="text-red-600" />}
              accent="bg-red-100"
              subtext="Derived from precipitation data"
              badge={{ text: weather.flood_risk, color: floodColors[weather.flood_risk] }}
            />
            <WeatherCard
              label="Storm Intensity"
              value={weather.storm_intensity}
              icon={<Zap size={16} className="text-amber-600" />}
              accent="bg-amber-100"
              subtext="Based on wind gust analysis"
              badge={{ text: weather.storm_intensity, color: stormColors[weather.storm_intensity] }}
            />
            <WeatherCard
              label="Wind Gusts"
              value={weather.wind_gusts_kmh.toFixed(0)}
              unit="km/h"
              icon={<Cloud size={16} className="text-slate-600" />}
              accent="bg-slate-100"
              subtext="Peak gust speed recorded"
            />
          </div>

          {/* Situation Assessment */}
          <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)] mb-1">Situation Assessment</h3>
            <p className="text-xs text-[hsl(215,16%,47%)] mb-4">AI-derived relief implications from current weather pattern</p>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                <div className="text-[10px] font-bold text-blue-700 uppercase tracking-wider mb-2">Flood Vulnerability</div>
                <div className="text-xs text-blue-800 leading-relaxed">
                  {weather.rainfall_mm > 60
                    ? "High risk of flash flooding. Pre-position boats and water rescue equipment. Evacuate riverside villages."
                    : weather.rainfall_mm > 20
                    ? "Moderate rainfall — monitor drainage capacity. Alert NGOs for potential flooding in low-lying areas."
                    : "Low flood risk currently. Continue standard supply operations."}
                </div>
              </div>
              <div className="bg-violet-50 border border-violet-100 rounded-lg p-4">
                <div className="text-[10px] font-bold text-violet-700 uppercase tracking-wider mb-2">Supply Route Impact</div>
                <div className="text-xs text-violet-800 leading-relaxed">
                  {weather.wind_gusts_kmh > 80
                    ? "Severe wind gusts. Ground transport only — suspend air drops. Expect 24-48 hour delivery delays."
                    : weather.wind_gusts_kmh > 40
                    ? "Moderate wind conditions. Helicopter operations restricted to essential-only. Road transport advised."
                    : "Favorable conditions for all supply chain operations. Full logistics capacity available."}
                </div>
              </div>
              <div className="bg-orange-50 border border-orange-100 rounded-lg p-4">
                <div className="text-[10px] font-bold text-orange-700 uppercase tracking-wider mb-2">Health Risk Advisory</div>
                <div className="text-xs text-orange-800 leading-relaxed">
                  {weather.temperature_c > 38
                    ? "Extreme heat alert. Prioritize water delivery and heat illness prevention supplies. Restrict outdoor volunteer activity to early morning."
                    : weather.temperature_c > 33
                    ? "High temperature conditions. Increase water and ORS delivery. Monitor for heat exhaustion among relief workers."
                    : "Temperature within normal range. Standard health protocols apply."}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
