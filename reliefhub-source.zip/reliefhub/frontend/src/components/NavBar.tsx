import { NavLink } from "react-router-dom";
import { Shield, FlaskConical, Radar } from "lucide-react";

export default function NavBar() {
  const links = [
    { href: "/", label: "Live Dashboard", icon: <Shield size={13} />, exact: true },
    { href: "/testing", label: "Simulation", icon: <FlaskConical size={13} />, exact: false },
    { href: "/radar", label: "Radar Portal", icon: <Radar size={13} />, exact: false },
  ];

  return (
    <nav className="bg-[hsl(222,47%,11%)] px-4 py-2 flex items-center gap-3 sticky top-0 z-[9998]">
      <div className="flex items-center gap-2 mr-4">
        <div className="w-5 h-5 rounded-full bg-[hsl(142,76%,36%)] flex items-center justify-center">
          <Shield size={11} className="text-white" />
        </div>
        <span className="text-white text-xs font-bold tracking-tight hidden sm:block">ReliefHub</span>
      </div>
      <div className="flex items-center gap-1">
        {links.map(({ href, label, icon, exact }) => (
          <NavLink
            key={href}
            to={href}
            end={exact}
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                isActive
                  ? "bg-white text-[hsl(222,47%,11%)]"
                  : "text-white/70 hover:text-white hover:bg-white/10"
              }`
            }
          >
            {icon}
            <span className="hidden sm:inline">{label}</span>
            <span className="sm:hidden">{label.split(" ")[0]}</span>
          </NavLink>
        ))}
      </div>
      <div className="ml-auto flex items-center gap-1.5 bg-white/10 px-2.5 py-1 rounded-full">
        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
        <span className="text-[10px] font-semibold text-white/70">Ops Online</span>
      </div>
    </nav>
  );
}
