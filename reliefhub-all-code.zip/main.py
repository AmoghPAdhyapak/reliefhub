import os
import sqlite3
import time
from contextlib import closing
from typing import List, Optional, Dict, Any
from datetime import datetime
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# =====================================================================
# 1. APP + CORS
# =====================================================================
app = FastAPI(
    title="ReliefHub Core API Engine",
    description="AI-Powered Disaster Relief Coordination Platform",
    version="1.2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================================
# 2. SQLITE DATABASE
# =====================================================================
DB_PATH = os.path.join(os.path.dirname(__file__), "reliefhub.db")

def _db():
    return sqlite3.connect(DB_PATH)

def init_db():
    with closing(_db()) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sos_villages (
                id TEXT PRIMARY KEY,
                name TEXT, status TEXT, needs TEXT,
                families INTEGER, metrics TEXT,
                tracking_demand TEXT,
                lat REAL, lng REAL,
                aid_received INTEGER DEFAULT 0,
                severity_score INTEGER, need_score INTEGER,
                priority_breakdown TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS activities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                actor TEXT,
                action TEXT,
                village TEXT,
                details TEXT
            )
        """)
        conn.commit()

def save_village(v: Dict[str, Any]):
    with closing(_db()) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO sos_villages VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (v["id"], v["name"], v["status"], v["needs"], v["families"],
             v["metrics"], v["trackingDemand"],
             v["position"]["lat"], v["position"]["lng"],
             v["aid_received"], v["severity_score"], v["need_score"],
             str(v.get("priority_breakdown", {})))
        )
        conn.commit()

def load_saved_villages() -> List[Dict[str, Any]]:
    with closing(_db()) as conn:
        rows = conn.execute("SELECT * FROM sos_villages").fetchall()
    result = []
    for r in rows:
        import json
        pb = {}
        try:
            pb = json.loads(r[12]) if r[12] else {}
        except:
            pass
        result.append({
            "id": r[0], "name": r[1], "status": r[2], "needs": r[3],
            "families": r[4], "metrics": r[5], "trackingDemand": r[6],
            "position": {"lat": r[7], "lng": r[8]},
            "aid_received": r[9], "severity_score": r[10], "need_score": r[11],
            "priority_breakdown": pb
        })
    return result

def log_activity(actor: str, action: str, village: str, details: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with closing(_db()) as conn:
        conn.execute(
            "INSERT INTO activities (timestamp, actor, action, village, details) VALUES (?,?,?,?,?)",
            (ts, actor, action, village, details)
        )
        conn.commit()

def load_activities(limit: int = 50) -> List[Dict[str, Any]]:
    with closing(_db()) as conn:
        rows = conn.execute(
            "SELECT timestamp, actor, action, village, details FROM activities ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [
        {"timestamp": r[0], "actor": r[1], "action": r[2], "village": r[3], "details": r[4]}
        for r in rows
    ]

# =====================================================================
# 3. PRIORITY ENGINE
# =====================================================================
def compute_priority_breakdown(
    lat: float, lng: float,
    severity_indicator: int, crowd_verification_count: int,
    families: int, aid_received: int
) -> Dict[str, Any]:
    """
    Priority Engine scoring factors:
    - Geographical Assignment: 0-30 (based on location vulnerability)
    - Volunteer Report Score: 0-25 (derived from family count)
    - NGO Report Score: 0-15 (based on aid gaps)
    - Crowd Verification: 0-20 (verification count * 5)
    - Disaster Severity: 0-30 (severity indicator)
    - Previous Aid Impact: -20 to 0 (negatives for well-served)
    """
    geo = min(abs(13.5 - lat) * 10 + abs(80 - lng) * 0.5, 30)
    vol = min(families * 0.2, 25)
    ngo = max(15 - aid_received * 0.2, 0)
    crowd = min(crowd_verification_count * 5, 20)
    severity = min(severity_indicator, 30)
    aid_impact = max(-20, -aid_received * 0.3)

    final = int(geo + vol + ngo + crowd + severity + aid_impact)
    classification = "critical" if final >= 75 else "moderate" if final >= 40 else "covered"

    return {
        "geographical_score": round(geo, 1),
        "volunteer_report_score": round(vol, 1),
        "ngo_report_score": round(ngo, 1),
        "crowd_verification_score": round(crowd, 1),
        "disaster_severity_score": round(severity, 1),
        "previous_aid_impact": round(aid_impact, 1),
        "final_priority_score": final,
        "classification": classification,
    }

def _priority_score(v: Dict[str, Any]) -> int:
    pb = v.get("priority_breakdown", {})
    return pb.get("final_priority_score", 0)

def _status_from_score(s: int) -> str:
    return "critical" if s >= 75 else "moderate" if s >= 40 else "covered"

# =====================================================================
# 4. IN-MEMORY DATA
# =====================================================================
dashboard_stats: Dict[str, Any] = {
    "villages_affected": 3,
    "families_helped": 1240,
    "active_ngos": 18,
    "items_delivered": 4850,
}

villages_db: List[Dict[str, Any]] = [
    {
        "id": "v1", "name": "Village Alpha Cluster", "status": "critical",
        "needs": "Food Kits & Clean Water", "families": 150,
        "metrics": "Severity Index: 88% | Deficit Escalation Active",
        "trackingDemand": "High Priority Influx (12 hours remaining)",
        "position": {"lat": 13.0827, "lng": 80.2707},
        "aid_received": 20, "severity_score": 45, "need_score": 40,
        "priority_breakdown": {
            "geographical_score": 28.5, "volunteer_report_score": 25.0,
            "ngo_report_score": 11.0, "crowd_verification_score": 15.0,
            "disaster_severity_score": 28.0, "previous_aid_impact": -6.0,
            "final_priority_score": 102, "classification": "critical",
        },
    },
    {
        "id": "v2", "name": "Village Beta Sector", "status": "moderate",
        "needs": "Antibiotics & Medical Field Tents", "families": 85,
        "metrics": "Severity Index: 52% | Stable Distribution Target",
        "trackingDemand": "Moderate Maintenance Cycle Pool",
        "position": {"lat": 12.9716, "lng": 77.5946},
        "aid_received": 45, "severity_score": 30, "need_score": 50,
        "priority_breakdown": {
            "geographical_score": 22.0, "volunteer_report_score": 17.0,
            "ngo_report_score": 6.0, "crowd_verification_score": 10.0,
            "disaster_severity_score": 22.0, "previous_aid_impact": -9.0,
            "final_priority_score": 68, "classification": "moderate",
        },
    },
    {
        "id": "v3", "name": "Village Gamma Outpost", "status": "covered",
        "needs": "None Requested", "families": 210,
        "metrics": "Severity Index: 12% | Operations Satisfied",
        "trackingDemand": "Distribution Loop Concluded",
        "position": {"lat": 19.0760, "lng": 72.8777},
        "aid_received": 95, "severity_score": 10, "need_score": 15,
        "priority_breakdown": {
            "geographical_score": 18.0, "volunteer_report_score": 20.0,
            "ngo_report_score": 2.0, "crowd_verification_score": 5.0,
            "disaster_severity_score": 8.0, "previous_aid_impact": -20.0,
            "final_priority_score": 33, "classification": "covered",
        },
    },
]

supply_tracking: Dict[str, Any] = {
    "food_kits": {"total": 2500, "in_transit": 800, "delivered": 1200},
    "medicines": {"total": 1000, "in_transit": 100, "delivered": 850},
    "water": {"total": 5000, "in_transit": 1200, "delivered": 3100},
    "blankets": {"total": 1800, "in_transit": 400, "delivered": 900},
    "tents": {"total": 600, "in_transit": 150, "delivered": 280},
}

# =====================================================================
# 5. STARTUP
# =====================================================================
@app.on_event("startup")
def on_startup():
    init_db()
    saved = load_saved_villages()
    existing_ids = {v["id"] for v in villages_db}
    for v in saved:
        if v["id"] not in existing_ids:
            villages_db.append(v)
            dashboard_stats["families_helped"] += v["families"]
    dashboard_stats["villages_affected"] = len(villages_db)

    # Seed pre-loaded activity log
    if not load_activities(limit=1):
        events = [
            ("ReliefHub System", "Priority Engine Initialized", "All Villages", "Multi-factor scoring algorithm deployed"),
            ("NGO Alpha", "Delivered Supplies", "Village Beta Sector", "Food Kits (200 units) — 85 families served"),
            ("Volunteer Report", "Verified Need", "Village Alpha Cluster", "Crowd verification: 3 reports confirmed"),
            ("Priority Engine", "Score Recalculated", "Village Alpha Cluster", "Final score: 102 (Critical) — escalation triggered"),
            ("NGO Beta", "Delivered Supplies", "Village Gamma Outpost", "Clean Water (500L) — 210 families served"),
            ("Volunteer Report", "Verified Need", "Village Beta Sector", "Medical field tents request confirmed"),
        ]
        for actor, action, village, details in events:
            log_activity(actor, action, village, details)

# =====================================================================
# 6. SCHEMAS
# =====================================================================
class CoordinateSchema(BaseModel):
    lat: float
    lng: float

class PriorityBreakdown(BaseModel):
    geographical_score: float
    volunteer_report_score: float
    ngo_report_score: float
    crowd_verification_score: float
    disaster_severity_score: float
    previous_aid_impact: float
    final_priority_score: int
    classification: str

class VillageResponse(BaseModel):
    id: str
    name: str
    status: str
    needs: str
    families: int
    metrics: str
    trackingDemand: str
    position: CoordinateSchema
    aid_received: int
    severity_score: int
    need_score: int
    priority_breakdown: PriorityBreakdown

class DashboardResponse(BaseModel):
    villages_affected: int
    families_helped: int
    active_ngos: int
    items_delivered: int

class SosRequest(BaseModel):
    village: str = Field(..., example="Delta")
    resource: str = Field(..., example="Food Kits")
    families: int = Field(..., example=95)
    priority: str = Field(..., example="CRITICAL")
    lat: Optional[float] = 13.0
    lng: Optional[float] = 80.0
    severity_indicator: Optional[int] = 35
    crowd_verification_count: Optional[int] = 1

class SosResponse(BaseModel):
    success: bool
    message: str
    inserted_id: str
    calculated_priority: str
    priority_breakdown: PriorityBreakdown

class AllocateRequest(BaseModel):
    resource: str = Field(..., example="Food Kits")
    quantity: int = Field(..., example=50)

class AllocateResponse(BaseModel):
    recommended_village: str
    reason: str
    priority_score_calculated: int
    priority_breakdown: PriorityBreakdown

class DuplicateCheckRequest(BaseModel):
    village: str = Field(..., example="v1")
    resource: str = Field(..., example="Food Kits")

class DuplicateCheckResponse(BaseModel):
    duplicate: bool
    message: str
    suggested_village: Optional[str] = None
    priority_breakdown: Optional[PriorityBreakdown] = None

class ChatRequest(BaseModel):
    message: str = Field(..., example="Which village needs urgent help?")

class ChatResponse(BaseModel):
    response: str

class SupplyItem(BaseModel):
    total: int
    in_transit: int
    delivered: int

class SupplyTrackingResponse(BaseModel):
    food_kits: SupplyItem
    medicines: SupplyItem
    water: SupplyItem
    blankets: SupplyItem
    tents: SupplyItem

class ActivityItem(BaseModel):
    timestamp: str
    actor: str
    action: str
    village: str
    details: str

class ActivitiesResponse(BaseModel):
    activities: List[ActivityItem]

class AnalyticsResponse(BaseModel):
    critical: int
    moderate: int
    covered: int
    total: int

# =====================================================================
# 7. API ROUTES
# =====================================================================

@app.get("/api/v1/dashboard", response_model=DashboardResponse, tags=["Dashboard"])
def get_dashboard():
    dashboard_stats["villages_affected"] = len(villages_db)
    return dashboard_stats


@app.get("/api/v1/villages", response_model=List[VillageResponse], tags=["Logistics"])
def get_villages():
    return villages_db


@app.get("/api/v1/village/{village_id}", response_model=VillageResponse, tags=["Logistics"])
def get_village_detail(village_id: str):
    v = next((v for v in villages_db if v["id"] == village_id), None)
    if not v:
        raise HTTPException(status_code=404, detail="Village not found")
    return v


@app.get("/api/v1/priority/{village_id}", response_model=PriorityBreakdown, tags=["Priority Engine"])
def get_priority_breakdown(village_id: str):
    v = next((v for v in villages_db if v["id"] == village_id), None)
    if not v:
        raise HTTPException(status_code=404, detail="Village not found")
    return v.get("priority_breakdown", {})


@app.get("/api/v1/analytics", response_model=AnalyticsResponse, tags=["Analytics"])
def get_analytics():
    crit = len([v for v in villages_db if v["status"] == "critical"])
    mod = len([v for v in villages_db if v["status"] == "moderate"])
    cov = len([v for v in villages_db if v["status"] == "covered"])
    return {"critical": crit, "moderate": mod, "covered": cov, "total": len(villages_db)}


@app.get("/api/v1/activities", response_model=ActivitiesResponse, tags=["Activity Feed"])
def get_activities(limit: int = 20):
    return {"activities": load_activities(limit)}


@app.post("/api/v1/sos", response_model=SosResponse, status_code=status.HTTP_201_CREATED, tags=["Ingestion"])
def post_sos(payload: SosRequest):
    new_id = f"v{len(villages_db) + 1}"
    severity = payload.severity_indicator or 30
    verif = payload.crowd_verification_count or 1
    families = payload.families

    pb = compute_priority_breakdown(
        payload.lat, payload.lng,
        severity, verif,
        families, 0
    )
    s_status = pb["classification"]

    entry = {
        "id": new_id,
        "name": f"Sector {payload.village}",
        "status": s_status,
        "needs": payload.resource,
        "families": families,
        "metrics": f"Severity Index: {pb['final_priority_score']}% | Multi-Source Verification Confirmed",
        "trackingDemand": f"Engine Priority Tier: {s_status.upper()} Influx Block",
        "position": {"lat": payload.lat, "lng": payload.lng},
        "aid_received": 0,
        "severity_score": severity,
        "need_score": int(min(families * 0.5, 40)),
        "priority_breakdown": pb,
    }

    villages_db.append(entry)
    save_village(entry)
    dashboard_stats["families_helped"] += families

    log_activity(
        "SOS Portal",
        "Emergency Request Submitted",
        entry["name"],
        f"{families} families affected. Priority: {s_status.upper()} (Score: {pb['final_priority_score']}). Resource: {payload.resource}"
    )
    log_activity(
        "Priority Engine",
        "Score Recalculated",
        entry["name"],
        f"Final score: {pb['final_priority_score']} ({s_status.upper()}) — geographical={pb['geographical_score']}, volunteer={pb['volunteer_report_score']}, NGO={pb['ngo_report_score']}, crowd={pb['crowd_verification_score']}, severity={pb['disaster_severity_score']}, aid_impact={pb['previous_aid_impact']}"
    )

    return SosResponse(
        success=True,
        message="Multi-source priority score processed. Ingested into active layout matrix.",
        inserted_id=new_id,
        calculated_priority=s_status,
        priority_breakdown=pb,
    )


@app.post("/api/v1/allocate", response_model=AllocateResponse, tags=["AI Optimization"])
def post_allocate(payload: AllocateRequest):
    if not villages_db:
        raise HTTPException(status_code=404, detail="No village data found.")

    best = max(villages_db, key=_priority_score)
    best_score = _priority_score(best)
    pb = best.get("priority_breakdown", {})

    reason = (
        f"The Priority Engine selected {best['name']} (Score: {best_score}). "
        f"Active deficit: {best['needs']} — {best['families']} families affected. "
        f"Only {best['aid_received']}% of allocated supplies received."
    )

    log_activity(
        "AI Allocation Engine",
        "Resource Allocated",
        best["name"],
        f"{payload.resource} ({payload.quantity} units) recommended. Priority score: {best_score}. Reason: {reason}"
    )

    return AllocateResponse(
        recommended_village=best["name"],
        reason=reason,
        priority_score_calculated=best_score,
        priority_breakdown=pb,
    )


@app.post("/api/v1/duplicate-check", response_model=DuplicateCheckResponse, tags=["AI Optimization"])
def post_duplicate(payload: DuplicateCheckRequest):
    target = next((v for v in villages_db if v["id"] == payload.village), None)
    if not target:
        target = next((v for v in villages_db if payload.village.lower() in v["name"].lower()), None)

    if target:
        incoming = payload.resource.lower()
        existing = target["needs"].lower()
        is_dup = (
            incoming in existing
            or any(w in incoming for w in existing.split() if len(w) > 3)
            or (target["id"] == "v1" and "food" in incoming)
        )
        if is_dup:
            alt = next((v for v in villages_db if v["id"] != target["id"] and v["status"] == "critical"), None)
            if not alt:
                alt = next((v for v in villages_db if v["id"] != target["id"] and v["status"] == "moderate"), None)

            log_activity(
                "Duplicate Detection",
                "Conflict Alert",
                target["name"],
                f"{payload.resource} already allocated. Reroute suggested: {alt['name'] if alt else 'None'}"
            )

            return DuplicateCheckResponse(
                duplicate=True,
                message=f"⚠ Conflict: [{payload.resource}] matches open allocation for {target['name']}. Re-routing recommended.",
                suggested_village=alt["name"] if alt else "Unassigned Safe Sector",
                priority_breakdown=alt.get("priority_breakdown") if alt else None,
            )

    log_activity(
        "Duplicate Detection",
        "Clearance Verified",
        target["name"] if target else "Unknown",
        f"{payload.resource} — no conflicts detected"
    )

    return DuplicateCheckResponse(
        duplicate=False,
        message="✓ Clear Runway: No delivery overlaps detected for this asset class.",
        suggested_village=None,
        priority_breakdown=None,
    )


@app.post("/api/v1/chat", response_model=ChatResponse, tags=["AI Copilot"])
def post_chat(payload: ChatRequest):
    q = payload.message.lower()
    crits = [v for v in villages_db if v["status"] == "critical"]
    mod = [v for v in villages_db if v["status"] == "moderate"]
    cov = [v for v in villages_db if v["status"] == "covered"]

    def explain_village(v):
        pb = v.get("priority_breakdown", {})
        return (
            f"**{v['name']}** (Score: {pb.get('final_priority_score', 0)})")

    def explain_priority(v):
        pb = v.get("priority_breakdown", {})
        return (
            f"**Priority Breakdown for {v['name']}:**\n"
            f"- Geographical Assignment: {pb.get('geographical_score', 0)}/30\n"
            f"- Volunteer Report: {pb.get('volunteer_report_score', 0)}/25\n"
            f"- NGO Report: {pb.get('ngo_report_score', 0)}/15\n"
            f"- Crowd Verification: {pb.get('crowd_verification_score', 0)}/20\n"
            f"- Disaster Severity: {pb.get('disaster_severity_score', 0)}/30\n"
            f"- Previous Aid Impact: {pb.get('previous_aid_impact', 0)}\n"
            f"**Final Score: {pb.get('final_priority_score', 0)} → {pb.get('classification', 'unknown').upper()}**"
        )

    if any(k in q for k in ["priority", "score", "engine", "urgent", "critical", "breakdown"]):
        names = ", ".join(v["name"] for v in crits) or "None currently"
        if crits:
            top = crits[0]
            resp = (
                f"### 🤖 Priority Engine Audit\n\n"
                f"**Critical sectors:** {names}\n\n"
                f"{explain_priority(top)}\n\n"
                f"**Formula:** *(Geographical + Volunteer + NGO + Crowd + Severity) + Aid Impact*\n\n"
                f"**Action:** Route all supply drops to critical sectors immediately."
            )
        else:
            resp = "### 🤖 Priority Engine Audit\n\nNo critical sectors currently. All villages are stable."

    elif any(k in q for k in ["food", "supply", "send", "route", "allocate", "kits"]):
        top = max(villages_db, key=_priority_score)
        pb = top.get("priority_breakdown", {})
        resp = (
            f"### 📦 Logistics Directive\n\n"
            f"**Top priority destination:** {top['name']} (Score: {pb.get('final_priority_score', 0)})\n"
            f"**Deficit:** {top['needs']}\n"
            f"**Families at risk:** {top['families']}\n\n"
            f"Priority breakdown:")
        for k, v in pb.items():
            if k not in ("final_priority_score", "classification"):
                resp += f"\n- {k.replace('_', ' ').title()}: {v}"
        resp += f"\n\nRun a duplicate check before dispatching."

    elif any(k in q for k in ["duplicate", "collision", "double", "overlap"]):
        resp = (
            "### 🚨 Duplicate Detection Status\n\n"
            "Engine actively cross-references every delivery against village allocation records.\n\n"
            "**Known collision risk:** Village Alpha Cluster — food kits already scheduled.\n"
            "**Safe alternative:** Village Beta Sector (medicine deficit unmet).\n\n"
            "Use the Duplicate Detection panel to validate any NGO drop before dispatch."
        )

    elif any(k in q for k in ["village", "which", "who", "need help", "needs"]):
        if crits:
            v = crits[0]
            resp = (
                f"### 🏘️ Village Priority Report\n\n"
                f"{explain_priority(v)}\n\n"
                f"**Recommendation:** Immediate deployment to {v['name']}."
            )
        else:
            resp = "### 🏘️ Village Priority Report\n\nAll villages currently covered. No urgent action needed."

    elif any(k in q for k in ["medicine", "medical", "health", "antibiotic"]):
        resp = (
            "### 💊 Medical Supply Intelligence\n\n"
            "**Village Beta Sector** is the top medical destination.\n"
            "Deficit: Antibiotics & Medical Field Tents — 85 families.\n\n"
            "Severity Index: 68. Route medical supply flights immediately."
        )
    else:
        resp = (
            f"### 👋 ReliefHub AI Copilot Online\n\n"
            f"Connected to the Priority Engine.\n\n"
            f"* **Sectors monitored:** {len(villages_db)}\n"
            f"* **Critical:** {len(crits)} | **Moderate:** {len(mod)} | **Covered:** {len(cov)}\n"
            f"* **Duplication safeguards:** Active\n\n"
            f"Ask: *'Which village needs food?'* or *'Explain priority scores'*"
        )

    return ChatResponse(response=resp)


@app.get("/api/v1/supply-tracking", response_model=SupplyTrackingResponse, tags=["Supply Tracking"])
def get_supply():
    return supply_tracking


@app.get("/api/healthz", tags=["System"])
def healthz():
    return {"status": "ok", "version": "1.2.0", "villages": len(villages_db)}
