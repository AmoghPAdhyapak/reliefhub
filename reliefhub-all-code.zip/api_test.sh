#!/usr/bin/env bash

HOST="http://localhost:80"

echo "=== 1. DASHBOARD ==="
curl -s -X GET "$HOST/api/v1/dashboard" -H "Content-Type: application/json"
echo -e "\n"

echo "=== 2. VILLAGES (with geo + metrics) ==="
curl -s -X GET "$HOST/api/v1/villages" -H "Content-Type: application/json"
echo -e "\n"

echo "=== 3. SOS (Priority Engine) ==="
curl -s -X POST "$HOST/api/v1/sos" -H "Content-Type: application/json" \
  -d '{"village":"Delta","resource":"Clean Water","families":95,"priority":"CRITICAL","lat":14.5,"lng":79.1,"severity_indicator":50,"crowd_verification_count":3}'
echo -e "\n"

echo "=== 4. AI ALLOCATION (Priority Engine) ==="
curl -s -X POST "$HOST/api/v1/allocate" -H "Content-Type: application/json" \
  -d '{"resource":"Emergency Medical Packs","quantity":100}'
echo -e "\n"

echo "=== 5. DUPLICATE CHECK ==="
curl -s -X POST "$HOST/api/v1/duplicate-check" -H "Content-Type: application/json" \
  -d '{"village":"v1","resource":"Food Kits"}'
echo -e "\n"

echo "=== 6. AI CHAT ==="
curl -s -X POST "$HOST/api/v1/chat" -H "Content-Type: application/json" \
  -d '{"message":"Which village has the highest priority score?"}'
echo -e "\n"

echo "=== 7. SUPPLY TRACKING ==="
curl -s -X GET "$HOST/api/v1/supply-tracking" -H "Content-Type: application/json"
echo -e "\n"

echo "=== 8. HEALTHZ ==="
curl -s -X GET "$HOST/api/healthz"
echo -e "\n"
