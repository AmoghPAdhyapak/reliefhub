import { useEffect, useState } from "react";
import { useLanguage } from "./context/LanguageContext";

export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const { t } = useLanguage();
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1200);
    const t3 = setTimeout(() => onDone(), 2600);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-[99999] flex flex-col items-center justify-center bg-[hsl(222,47%,11%)] overflow-hidden">
      {/* Radial glow */}
      <div
        className="absolute inset-0 transition-opacity duration-700"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(22,163,74,0.18) 0%, transparent 70%)",
          opacity: phase >= 1 ? 1 : 0,
        }}
      />

      {/* Logo */}
      <div
        className="flex flex-col items-center gap-5 transition-all duration-700"
        style={{
          opacity: phase >= 1 ? 1 : 0,
          transform: phase >= 1 ? "scale(1) translateY(0)" : "scale(0.85) translateY(24px)",
        }}
      >
        {/* Shield logo */}
        <div
          className="relative flex items-center justify-center transition-all duration-500"
          style={{ filter: phase >= 1 ? "drop-shadow(0 0 32px rgba(22,163,74,0.6))" : "none" }}
        >
          <svg width="96" height="96" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M48 4L12 20V48C12 67.2 28 83.6 48 92C68 83.6 84 67.2 84 48V20L48 4Z"
              fill="hsl(142,76%,36%)"
              stroke="rgba(255,255,255,0.2)"
              strokeWidth="2"
            />
            <path
              d="M48 18L24 28V48C24 61.2 34.4 72.6 48 78C61.6 72.6 72 61.2 72 48V28L48 18Z"
              fill="hsl(142,76%,28%)"
            />
            <text x="48" y="55" textAnchor="middle" fill="white" fontSize="22" fontWeight="800" fontFamily="system-ui">RH</text>
          </svg>
        </div>

        <div className="text-center">
          <div
            className="text-4xl font-black text-white tracking-[0.12em] mb-2 transition-all duration-700"
            style={{ opacity: phase >= 1 ? 1 : 0, letterSpacing: "0.15em" }}
          >
            RELIEFHUB
          </div>
          <div
            className="text-[hsl(142,60%,65%)] text-sm font-medium tracking-wider transition-all duration-700 delay-100"
            style={{ opacity: phase >= 2 ? 1 : 0 }}
          >
            The Right Aid. The Right Place. The Right Time.
          </div>
        </div>
      </div>

      {/* Loading text */}
      <div
        className="absolute bottom-16 flex flex-col items-center gap-3 transition-all duration-500"
        style={{ opacity: phase >= 2 ? 1 : 0 }}
      >
        <div className="flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)]"
              style={{ animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }}
            />
          ))}
        </div>
        <div className="text-[hsl(215,16%,60%)] text-xs font-medium tracking-wider">
          {t("splash_loading")}
        </div>
        <div className="text-[hsl(215,16%,47%)] text-[10px]">
          {t("splash_init")}
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); opacity: 0.4; }
          50% { transform: translateY(-6px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
