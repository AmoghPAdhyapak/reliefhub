import { useState } from "react";
import { Search, Globe, ChevronRight } from "lucide-react";
import { LANGUAGES, useLanguage } from "./context/LanguageContext";

export default function LanguageSelection({ onDone }: { onDone: () => void }) {
  const { setLang } = useLanguage();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState("");

  const filtered = LANGUAGES.filter((l) => {
    const q = search.toLowerCase();
    return (
      l.name.toLowerCase().includes(q) ||
      l.native.toLowerCase().includes(q) ||
      l.code.includes(q)
    );
  });

  function choose(code: string) {
    setSelected(code);
    setTimeout(() => {
      setLang(code);
      onDone();
    }, 300);
  }

  return (
    <div className="fixed inset-0 z-[99998] bg-[hsl(210,40%,98%)] flex flex-col items-center justify-center p-4 overflow-y-auto">
      {/* Header */}
      <div className="text-center mb-8 animate-fade-in">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="bg-[hsl(142,76%,93%)] p-3 rounded-2xl">
            <Globe size={28} className="text-[hsl(142,76%,36%)]" />
          </div>
        </div>
        <h1 className="text-3xl font-black text-[hsl(222,47%,11%)] mb-2">Choose Your Language</h1>
        <p className="text-[hsl(215,16%,47%)] text-sm">
          Select your preferred language to continue
          <br />
          <span className="text-xs">भाषा चुनें · ಭಾಷೆ ಆರಿಸಿ · மொழி தேர்வு</span>
        </p>
      </div>

      {/* Search */}
      <div className="w-full max-w-md mb-6">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(215,16%,47%)]" />
          <input
            className="w-full pl-10 pr-4 py-3 border border-[hsl(214,32%,91%)] rounded-xl text-sm focus:outline-none focus:border-[hsl(142,76%,36%)] bg-white shadow-sm"
            placeholder="Search language... (e.g. Kannada, ಕನ್ನಡ, हिन्दी)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            autoFocus
          />
        </div>
      </div>

      {/* Language grid */}
      <div className="w-full max-w-2xl grid grid-cols-2 sm:grid-cols-3 gap-3">
        {filtered.map((lang) => (
          <button
            key={lang.code}
            onClick={() => choose(lang.code)}
            className={`group flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-200 text-center ${
              selected === lang.code
                ? "border-[hsl(142,76%,36%)] bg-[hsl(142,76%,93%)] scale-95"
                : "border-[hsl(214,32%,91%)] bg-white hover:border-[hsl(142,76%,36%)] hover:bg-[hsl(142,76%,97%)] hover:shadow-md hover:-translate-y-0.5"
            }`}
            dir={lang.dir || "ltr"}
          >
            <div className={`text-2xl font-bold transition-colors ${
              selected === lang.code
                ? "text-[hsl(142,76%,28%)]"
                : "text-[hsl(222,47%,11%)] group-hover:text-[hsl(142,76%,36%)]"
            }`}>
              {lang.native}
            </div>
            <div className="text-[10px] font-semibold text-[hsl(215,16%,47%)] uppercase tracking-wider">
              {lang.name}
            </div>
            {selected === lang.code && (
              <div className="flex items-center gap-1 text-[10px] font-bold text-[hsl(142,76%,36%)]">
                <ChevronRight size={10} />
                Selected
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Footer note */}
      <p className="mt-8 text-[10px] text-[hsl(215,16%,47%)] text-center">
        You can change the language at any time from the navigation bar
      </p>
    </div>
  );
}
