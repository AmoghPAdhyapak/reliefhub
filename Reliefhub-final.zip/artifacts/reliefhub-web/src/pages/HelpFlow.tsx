import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  MapPin, Keyboard, AlertTriangle, CheckCircle, Zap,
  ChevronRight, ArrowLeft, Loader2, Shield, Phone
} from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

type Step = "choose" | "gps_requesting" | "gps_done" | "manual" | "checking" | "result_disaster" | "result_clear";

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Delhi", "Jammu & Kashmir", "Ladakh", "Puducherry",
];

export default function HelpFlow() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const [step, setStep] = useState<Step>("choose");
  const [geoPos, setGeoPos] = useState<{ lat: number; lng: number } | null>(null);
  const [form, setForm] = useState({ state: "", district: "", village: "", pincode: "", landmark: "" });
  const [sosSubmitting, setSosSubmitting] = useState(false);
  const [sosSuccess, setSosSuccess] = useState(false);

  function startGps() {
    setStep("gps_requesting");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setStep("gps_done");
      },
      () => setStep("manual"),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }

  function checkDisasters() {
    setStep("checking");
    // Simulate real check: if SOS data exists in dashboard, show disaster; else show clear
    setTimeout(async () => {
      try {
        const r = await fetch("/api/v1/dashboard");
        const d = await r.json();
        if (d.villages_affected > 0) setStep("result_disaster");
        else setStep("result_clear");
      } catch {
        setStep("result_clear");
      }
    }, 2200);
  }

  async function submitEmergency() {
    setSosSubmitting(true);
    try {
      await fetch("/api/v1/sos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          village: form.village || "Field Report",
          resource: "Emergency Response",
          families: 50,
          priority: "CRITICAL",
          lat: geoPos?.lat ?? 13.0,
          lng: geoPos?.lng ?? 80.0,
          severity_indicator: 85,
          crowd_verification_count: 3,
          state: form.state || "Unknown",
        }),
      });
      setSosSuccess(true);
    } finally {
      setSosSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-[hsl(210,40%,98%)] flex flex-col">
      {/* Back button */}
      <div className="p-4">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-xs font-semibold text-[hsl(215,16%,47%)] hover:text-[hsl(222,47%,11%)] transition-colors"
        >
          <ArrowLeft size={14} />
          Back to Home
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md">

          {/* ── STEP: Choose method ─────────────────────────────── */}
          {step === "choose" && (
            <div className="bg-white rounded-2xl border border-[hsl(214,32%,91%)] shadow-lg p-6 animate-fade-in">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-red-100 p-3 rounded-xl">
                  <AlertTriangle size={24} className="text-red-600" />
                </div>
                <div>
                  <h1 className="text-lg font-black text-[hsl(222,47%,11%)]">{t("help_title")}</h1>
                  <p className="text-xs text-[hsl(215,16%,47%)]">{t("help_subtitle")}</p>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  onClick={startGps}
                  className="flex items-center gap-4 p-4 rounded-xl border-2 border-[hsl(142,76%,36%)] bg-[hsl(142,76%,97%)] hover:bg-[hsl(142,76%,93%)] transition-colors text-left"
                >
                  <div className="bg-[hsl(142,76%,36%)] p-2.5 rounded-lg shrink-0">
                    <MapPin size={20} className="text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-[hsl(222,47%,11%)]">{t("help_use_gps")}</div>
                    <div className="text-[10px] text-[hsl(215,16%,47%)] mt-0.5">Fastest — uses your device GPS</div>
                  </div>
                  <ChevronRight size={16} className="text-[hsl(142,76%,36%)] shrink-0" />
                </button>

                <button
                  onClick={() => setStep("manual")}
                  className="flex items-center gap-4 p-4 rounded-xl border-2 border-[hsl(214,32%,91%)] bg-white hover:border-[hsl(222,47%,11%)] hover:bg-[hsl(210,40%,98%)] transition-colors text-left"
                >
                  <div className="bg-[hsl(210,40%,96%)] p-2.5 rounded-lg shrink-0">
                    <Keyboard size={20} className="text-[hsl(222,47%,11%)]" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-[hsl(222,47%,11%)]">{t("help_manual")}</div>
                    <div className="text-[10px] text-[hsl(215,16%,47%)] mt-0.5">Enter state, district, village details</div>
                  </div>
                  <ChevronRight size={16} className="text-[hsl(215,16%,47%)] shrink-0" />
                </button>
              </div>

              {/* Emergency hotline */}
              <div className="mt-5 flex items-center gap-2.5 p-3 bg-red-50 border border-red-200 rounded-xl">
                <Phone size={14} className="text-red-600 shrink-0" />
                <div className="text-[10px] text-red-700 leading-relaxed">
                  <strong>National Emergency:</strong> Call <strong>112</strong> for immediate police/fire/ambulance. <strong>NDRF:</strong> 011-24363260
                </div>
              </div>
            </div>
          )}

          {/* ── STEP: GPS Requesting ────────────────────────────── */}
          {step === "gps_requesting" && (
            <div className="bg-white rounded-2xl border border-[hsl(214,32%,91%)] shadow-lg p-8 animate-fade-in flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full border-4 border-[hsl(142,76%,36%)] border-t-transparent animate-spin" />
              <h2 className="text-base font-bold text-[hsl(222,47%,11%)]">Acquiring GPS Location</h2>
              <p className="text-xs text-[hsl(215,16%,47%)]">Please allow location access when your browser asks...</p>
            </div>
          )}

          {/* ── STEP: GPS done ──────────────────────────────────── */}
          {step === "gps_done" && geoPos && (
            <div className="bg-white rounded-2xl border border-[hsl(214,32%,91%)] shadow-lg p-6 animate-fade-in">
              <div className="flex items-center gap-3 mb-5">
                <div className="bg-emerald-100 p-3 rounded-xl">
                  <MapPin size={24} className="text-emerald-600" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-[hsl(222,47%,11%)]">Location Acquired</h2>
                  <p className="text-[10px] text-[hsl(215,16%,47%)]">{geoPos.lat.toFixed(5)}°N, {geoPos.lng.toFixed(5)}°E</p>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex gap-2 mb-5">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse mt-1 shrink-0" />
                <div className="text-xs text-emerald-700 leading-relaxed">
                  Your GPS coordinates are ready. Click below to check for active disasters in your area.
                </div>
              </div>

              {sosSuccess ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center">
                  <CheckCircle size={32} className="text-emerald-600 mx-auto mb-2" />
                  <div className="text-sm font-bold text-emerald-800">Emergency Transmitted!</div>
                  <div className="text-xs text-emerald-700 mt-1">Your SOS has been logged. NGOs near your location will be alerted.</div>
                  <button onClick={() => navigate("/dashboard")} className="mt-3 text-xs font-semibold text-emerald-600 hover:underline">
                    Track on Dashboard →
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={checkDisasters}
                    className="w-full bg-[hsl(222,47%,11%)] hover:bg-[hsl(222,47%,8%)] text-white py-3 rounded-xl font-bold text-sm transition-colors"
                  >
                    {t("help_check_btn")}
                  </button>
                  <button
                    onClick={submitEmergency}
                    disabled={sosSubmitting}
                    className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
                  >
                    {sosSubmitting ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                    Submit Emergency SOS
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ── STEP: Manual form ───────────────────────────────── */}
          {step === "manual" && (
            <div className="bg-white rounded-2xl border border-[hsl(214,32%,91%)] shadow-lg p-6 animate-fade-in">
              <h2 className="text-base font-bold text-[hsl(222,47%,11%)] mb-1">{t("help_title")}</h2>
              <p className="text-xs text-[hsl(215,16%,47%)] mb-5">Enter your location details to check for active disasters</p>

              <div className="flex flex-col gap-3">
                <div>
                  <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider block mb-1">{t("help_state")} *</label>
                  <select
                    className="w-full border border-[hsl(214,32%,91%)] rounded-lg px-3 py-2.5 text-sm text-[hsl(222,47%,11%)] focus:outline-none focus:border-[hsl(142,76%,36%)] bg-white"
                    value={form.state}
                    onChange={(e) => setForm({ ...form, state: e.target.value })}
                  >
                    <option value="">Select State...</option>
                    {INDIAN_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider block mb-1">{t("help_district")} *</label>
                  <input
                    className="w-full border border-[hsl(214,32%,91%)] rounded-lg px-3 py-2.5 text-sm text-[hsl(222,47%,11%)] focus:outline-none focus:border-[hsl(142,76%,36%)]"
                    placeholder="e.g. Kurnool"
                    value={form.district}
                    onChange={(e) => setForm({ ...form, district: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider block mb-1">{t("help_village_label")}</label>
                    <input
                      className="w-full border border-[hsl(214,32%,91%)] rounded-lg px-3 py-2.5 text-sm text-[hsl(222,47%,11%)] focus:outline-none focus:border-[hsl(142,76%,36%)]"
                      placeholder="Village name"
                      value={form.village}
                      onChange={(e) => setForm({ ...form, village: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider block mb-1">{t("help_pincode")}</label>
                    <input
                      className="w-full border border-[hsl(214,32%,91%)] rounded-lg px-3 py-2.5 text-sm text-[hsl(222,47%,11%)] focus:outline-none focus:border-[hsl(142,76%,36%)]"
                      placeholder="500001"
                      maxLength={6}
                      value={form.pincode}
                      onChange={(e) => setForm({ ...form, pincode: e.target.value.replace(/\D/, "") })}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider block mb-1">{t("help_landmark")}</label>
                  <input
                    className="w-full border border-[hsl(214,32%,91%)] rounded-lg px-3 py-2.5 text-sm text-[hsl(222,47%,11%)] focus:outline-none focus:border-[hsl(142,76%,36%)]"
                    placeholder="Near temple, school, etc."
                    value={form.landmark}
                    onChange={(e) => setForm({ ...form, landmark: e.target.value })}
                  />
                </div>
              </div>

              <button
                onClick={checkDisasters}
                disabled={!form.state || !form.district}
                className="w-full mt-5 bg-[hsl(222,47%,11%)] hover:bg-[hsl(222,47%,8%)] disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 rounded-xl font-bold text-sm transition-colors"
              >
                {t("help_check_btn")}
              </button>
            </div>
          )}

          {/* ── STEP: Checking ──────────────────────────────────── */}
          {step === "checking" && (
            <div className="bg-white rounded-2xl border border-[hsl(214,32%,91%)] shadow-lg p-8 animate-fade-in flex flex-col items-center text-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-4 border-[hsl(210,40%,91%)] border-t-[hsl(222,47%,11%)] animate-spin" />
                <Shield size={20} className="absolute inset-0 m-auto text-[hsl(222,47%,11%)]" />
              </div>
              <h2 className="text-base font-bold text-[hsl(222,47%,11%)]">{t("help_checking")}</h2>
              <div className="flex flex-col gap-1.5 text-xs text-[hsl(215,16%,47%)] text-left w-full max-w-xs">
                {["Checking weather conditions...", "Scanning disaster indicators...", "Verifying NGO reports...", "Analyzing geographic risk..."].map((msg, i) => (
                  <div key={i} className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: `${i * 0.4}s` }}>
                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
                    {msg}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── STEP: Disaster found ────────────────────────────── */}
          {step === "result_disaster" && (
            <div className="bg-white rounded-2xl border border-red-200 shadow-lg p-6 animate-fade-in">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-red-100 p-3 rounded-xl">
                  <AlertTriangle size={24} className="text-red-600" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-red-800">Active Disaster Detected</h2>
                  <p className="text-xs text-red-600">Relief operations are in progress</p>
                </div>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
                <div className="text-xs text-red-700 space-y-2">
                  <div className="flex gap-2"><AlertTriangle size={12} className="shrink-0 mt-0.5" /><span>Critical incidents active in your region</span></div>
                  <div className="flex gap-2"><AlertTriangle size={12} className="shrink-0 mt-0.5" /><span>NGOs have been dispatched to affected areas</span></div>
                  <div className="flex gap-2"><AlertTriangle size={12} className="shrink-0 mt-0.5" /><span>Relief supplies are in transit</span></div>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => navigate("/dashboard")} className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2">
                  <Shield size={16} /> View Live Dashboard
                </button>
                <button onClick={() => navigate("/testing")} className="w-full bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)] py-3 rounded-xl font-bold text-sm transition-colors">
                  Run Full Simulation
                </button>
              </div>
            </div>
          )}

          {/* ── STEP: No disaster ───────────────────────────────── */}
          {step === "result_clear" && (
            <div className="bg-white rounded-2xl border border-emerald-200 shadow-lg p-6 animate-fade-in">
              <div className="flex items-center gap-3 mb-5">
                <div className="bg-emerald-100 p-3 rounded-xl">
                  <CheckCircle size={24} className="text-emerald-600" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-emerald-800">{t("help_no_disaster")}</h2>
                  <p className="text-xs text-emerald-600">Your area appears safe</p>
                </div>
              </div>
              <div className="space-y-2 mb-5">
                {[t("monitoring_active"), t("no_incident"), t("weather_stable"), t("standing_by")].map((msg) => (
                  <div key={msg} className="flex items-center gap-2.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-2 rounded-lg">
                    <CheckCircle size={12} className="text-emerald-600 shrink-0" />
                    {msg}
                  </div>
                ))}
              </div>
              <p className="text-xs text-[hsl(215,16%,47%)] mb-4">
                Want to see how ReliefHub responds to real disaster scenarios? Run a simulation.
              </p>
              <button
                onClick={() => navigate("/testing")}
                className="w-full bg-[hsl(222,47%,11%)] hover:bg-[hsl(222,47%,8%)] text-white py-3 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2"
              >
                <Zap size={16} />
                {t("help_run_sim")}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
