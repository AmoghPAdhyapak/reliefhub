import { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import {
  Radio, AlertTriangle, AlertOctagon, CircleCheck, Activity, RefreshCcw,
  Wind, Droplets, Thermometer, CloudRain, Zap, Eye, CloudLightning, ArrowUp
} from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

interface Village {
  id: string;
  name: string;
  status: "critical" | "moderate" | "covered";
  needs: string;
  families: number;
  position: { lat: number; lng: number };
  aid_received: number;
  state: string;
  priority_breakdown: { final_priority_score: number; classification: string };
}

interface WeatherCity {
  name: string;
  state: string;
  lat: number;
  lng: number;
  rainfall: number;
  windSpeed: number;
  floodRisk: "Critical" | "High" | "Moderate" | "Low";
  temp: number;
  humidity: number;
  alerts: string[];
}

const MONITOR_CITIES: WeatherCity[] = [
  { name: "Chennai", state: "Tamil Nadu", lat: 13.08, lng: 80.27, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 32, humidity: 72, alerts: [] },
  { name: "Mumbai", state: "Maharashtra", lat: 19.07, lng: 72.87, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 30, humidity: 80, alerts: [] },
  { name: "Kolkata", state: "West Bengal", lat: 22.57, lng: 88.36, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 29, humidity: 85, alerts: [] },
  { name: "Bengaluru", state: "Karnataka", lat: 12.97, lng: 77.59, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 27, humidity: 65, alerts: [] },
  { name: "Hyderabad", state: "Telangana", lat: 17.38, lng: 78.48, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 31, humidity: 60, alerts: [] },
  { name: "Bhubaneswar", state: "Odisha", lat: 20.30, lng: 85.84, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 33, humidity: 75, alerts: [] },
  { name: "Patna", state: "Bihar", lat: 25.59, lng: 85.13, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 34, humidity: 70, alerts: [] },
  { name: "Ahmedabad", state: "Gujarat", lat: 23.02, lng: 72.57, rainfall: 0, windSpeed: 0, floodRisk: "Low", temp: 36, humidity: 50, alerts: [] },
];

function RadarSweep({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const angleRef = useRef(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const r = Math.min(cx, cy) - 4;

    // Blip positions (random but stable)
    const blips = [
      { a: 0.8, d: 0.45 }, { a: 2.1, d: 0.7 }, { a: 3.4, d: 0.35 },
      { a: 1.3, d: 0.6 }, { a: 4.2, d: 0.8 }, { a: 5.1, d: 0.55 },
      { a: 0.3, d: 0.9 }, { a: 2.7, d: 0.25 },
    ];

    function draw() {
      if (!active) return;
      ctx.clearRect(0, 0, W, H);

      // Background circle
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,20,10,0.85)";
      ctx.fill();
      ctx.strokeStyle = "rgba(22,163,74,0.3)";
      ctx.lineWidth = 1;
      ctx.stroke();

      // Concentric rings
      for (let i = 1; i <= 4; i++) {
        ctx.beginPath();
        ctx.arc(cx, cy, (r * i) / 4, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(22,163,74,${0.08 + i * 0.03})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Crosshairs
      ctx.strokeStyle = "rgba(22,163,74,0.1)";
      ctx.lineWidth = 0.5;
      ctx.beginPath(); ctx.moveTo(cx - r, cy); ctx.lineTo(cx + r, cy); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx, cy + r); ctx.stroke();

      // Sweep gradient
      const a = angleRef.current;
      // Simulate sweep with arc fill
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r - 2, a - Math.PI / 3, a, false);
      ctx.closePath();
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      g.addColorStop(0, "rgba(22,163,74,0.0)");
      g.addColorStop(0.5, "rgba(22,163,74,0.12)");
      g.addColorStop(1, "rgba(22,163,74,0.28)");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.restore();

      // Sweep line
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + r * Math.cos(a), cy + r * Math.sin(a));
      ctx.strokeStyle = "rgba(22,163,74,0.9)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      // Blips
      blips.forEach((b) => {
        const bx = cx + b.d * r * Math.cos(b.a);
        const by = cy + b.d * r * Math.sin(b.a);
        const angleDiff = ((a - b.a) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
        if (angleDiff < 0.4) {
          const brightness = 1 - angleDiff / 0.4;
          ctx.beginPath();
          ctx.arc(bx, by, 3, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(22,163,74,${brightness * 0.9})`;
          ctx.fill();
          ctx.beginPath();
          ctx.arc(bx, by, 6, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(22,163,74,${brightness * 0.2})`;
          ctx.fill();
        }
      });

      // Center dot
      ctx.beginPath();
      ctx.arc(cx, cy, 3, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(22,163,74,0.8)";
      ctx.fill();

      angleRef.current = (a + 0.02) % (Math.PI * 2);
      rafRef.current = requestAnimationFrame(draw);
    }

    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      width={220}
      height={220}
      className="rounded-full"
      style={{ imageRendering: "pixelated" }}
    />
  );
}

function riskColor(risk: string) {
  if (risk === "Critical") return "text-red-400";
  if (risk === "High") return "text-orange-400";
  if (risk === "Moderate") return "text-yellow-400";
  return "text-emerald-400";
}

function riskBg(risk: string) {
  if (risk === "Critical") return "bg-red-900/30 border-red-700/40";
  if (risk === "High") return "bg-orange-900/30 border-orange-700/40";
  if (risk === "Moderate") return "bg-yellow-900/30 border-yellow-700/40";
  return "bg-emerald-900/20 border-emerald-700/30";
}

export default function RadarPage() {
  const { t } = useLanguage();
  const [villages, setVillages] = useState<Village[]>([]);
  const [cities, setCities] = useState<WeatherCity[]>(MONITOR_CITIES);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [sweepActive, setSweepActive] = useState(true);

  async function fetchData() {
    setLoading(true);
    try {
      // Fetch villages
      const vr = await fetch("/api/v1/villages");
      const vd = await vr.json();
      setVillages(vd.villages || []);

      // Fetch real weather from Open-Meteo (free, no API key)
      const updated: WeatherCity[] = await Promise.all(
        MONITOR_CITIES.map(async (city) => {
          try {
            const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lng}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation&hourly=precipitation&forecast_days=1&timezone=Asia%2FKolkata`;
            const wr = await fetch(url);
            const wd = await wr.json();
            const cur = wd.current || {};
            const rainfall = cur.precipitation ?? 0;
            const windSpeed = Math.round(cur.wind_speed_10m ?? 0);
            const temp = Math.round(cur.temperature_2m ?? city.temp);
            const humidity = Math.round(cur.relative_humidity_2m ?? city.humidity);
            // Determine flood risk from rainfall + wind
            let floodRisk: WeatherCity["floodRisk"] = "Low";
            const alerts: string[] = [];
            if (rainfall > 50) { floodRisk = "Critical"; alerts.push("Extreme Rainfall"); }
            else if (rainfall > 20) { floodRisk = "High"; alerts.push("Heavy Rain"); }
            else if (rainfall > 5) { floodRisk = "Moderate"; alerts.push("Moderate Rain"); }
            if (windSpeed > 60) alerts.push("High Winds");
            if (humidity > 90) alerts.push("High Humidity");
            return { ...city, rainfall, windSpeed, floodRisk, temp, humidity, alerts };
          } catch {
            return city;
          }
        })
      );
      setCities(updated);
    } finally {
      setLoading(false);
      setLastRefresh(new Date());
    }
  }

  useEffect(() => { fetchData(); }, []);

  const criticalCities = cities.filter((c) => c.floodRisk === "Critical" || c.floodRisk === "High");
  const iconFor = (status: string) => L.divIcon({
    className: "",
    html: `<div style="width:12px;height:12px;border-radius:50%;background:${
      status === "critical" ? "#ef4444" : status === "moderate" ? "#f97316" : "#22c55e"
    };border:2px solid white;box-shadow:0 0 8px 3px ${
      status === "critical" ? "rgba(239,68,68,0.5)" : status === "moderate" ? "rgba(249,115,22,0.5)" : "rgba(34,197,94,0.3)"
    }"></div>`,
    iconSize: [12, 12],
    iconAnchor: [6, 6],
  });

  return (
    <div className="min-h-screen bg-[hsl(222,47%,11%)] text-white">
      {/* Header */}
      <div className="border-b border-white/10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-[hsl(142,76%,20%)] p-2 rounded-lg">
            <Radio size={16} className="text-[hsl(142,76%,60%)]" />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-wide">{t("radar_title")}</h1>
            <p className="text-[10px] text-white/50">{t("radar_subtitle")}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-[10px] text-white/40">
            Updated {lastRefresh.toLocaleTimeString()}
          </div>
          <button
            onClick={fetchData}
            disabled={loading}
            className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg text-[10px] font-semibold transition-colors"
          >
            <RefreshCcw size={11} className={loading ? "animate-spin" : ""} />
            Refresh
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row h-[calc(100vh-104px)]">
        {/* ── Left sidebar ─────────────────────────────────── */}
        <div className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r border-white/10 flex flex-col overflow-hidden">
          {/* Radar display */}
          <div className="p-4 flex flex-col items-center border-b border-white/10">
            <div className="relative mb-3">
              <RadarSweep active={sweepActive} />
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <div className="text-[8px] text-[hsl(142,76%,60%)] font-bold tracking-widest opacity-60 mt-16">
                  LIVE SCAN
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-[10px]">
              <div className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
              <span className="text-[hsl(142,76%,60%)] font-semibold">Active Regional Monitoring</span>
            </div>
            <button
              onClick={() => setSweepActive(!sweepActive)}
              className="mt-2 text-[9px] text-white/30 hover:text-white/60 transition-colors"
            >
              {sweepActive ? "Pause sweep" : "Resume sweep"}
            </button>
          </div>

          {/* Alert summary */}
          <div className="p-3 border-b border-white/10">
            <div className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-2">Alert Summary</div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Critical", count: cities.filter((c) => c.floodRisk === "Critical").length, color: "text-red-400" },
                { label: "High Risk", count: cities.filter((c) => c.floodRisk === "High").length, color: "text-orange-400" },
                { label: "Moderate", count: cities.filter((c) => c.floodRisk === "Moderate").length, color: "text-yellow-400" },
                { label: "Stable", count: cities.filter((c) => c.floodRisk === "Low").length, color: "text-emerald-400" },
              ].map((s) => (
                <div key={s.label} className="bg-white/5 rounded-lg p-2 text-center">
                  <div className={`text-lg font-black ${s.color}`}>{s.count}</div>
                  <div className="text-[9px] text-white/40">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* City weather list */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            <div className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-1">
              City Weather Monitor
            </div>
            {cities.map((city) => (
              <div
                key={city.name}
                className={`rounded-xl border p-2.5 transition-all ${riskBg(city.floodRisk)}`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div>
                    <div className="text-xs font-bold text-white">{city.name}</div>
                    <div className="text-[9px] text-white/40">{city.state}</div>
                  </div>
                  <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${riskBg(city.floodRisk)} ${riskColor(city.floodRisk)}`}>
                    {city.floodRisk}
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  <div className="flex flex-col items-center">
                    <CloudRain size={9} className="text-blue-400 mb-0.5" />
                    <div className="text-[9px] font-bold text-white">{city.rainfall.toFixed(1)}</div>
                    <div className="text-[8px] text-white/30">mm</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <Wind size={9} className="text-teal-400 mb-0.5" />
                    <div className="text-[9px] font-bold text-white">{city.windSpeed}</div>
                    <div className="text-[8px] text-white/30">km/h</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <Thermometer size={9} className="text-orange-400 mb-0.5" />
                    <div className="text-[9px] font-bold text-white">{city.temp}°</div>
                    <div className="text-[8px] text-white/30">°C</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <Droplets size={9} className="text-blue-300 mb-0.5" />
                    <div className="text-[9px] font-bold text-white">{city.humidity}%</div>
                    <div className="text-[8px] text-white/30">RH</div>
                  </div>
                </div>
                {city.alerts.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {city.alerts.map((a) => (
                      <span key={a} className="text-[8px] px-1.5 py-0.5 bg-orange-900/50 text-orange-300 rounded-full border border-orange-700/40">
                        {a}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── Map + panels ─────────────────────────────────── */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Map */}
          <div className="flex-1 relative">
            {loading && (
              <div className="absolute inset-0 z-[1000] bg-black/50 flex items-center justify-center">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-8 h-8 border-2 border-[hsl(142,76%,36%)] border-t-transparent rounded-full animate-spin" />
                  <div className="text-xs text-white/60">Fetching weather data...</div>
                </div>
              </div>
            )}
            <MapContainer
              center={[20.5, 80.0]}
              zoom={5}
              style={{ height: "100%", width: "100%" }}
              zoomControl={false}
            >
              <TileLayer
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                maxZoom={19}
              />
              {/* Village markers */}
              {villages.map((v) => (
                <Marker
                  key={v.id}
                  position={[v.position.lat, v.position.lng]}
                  icon={iconFor(v.status)}
                >
                  <Popup>
                    <div className="text-xs">
                      <strong>{v.name}</strong> — {v.status}
                      <br />{v.families} families · Score: {v.priority_breakdown.final_priority_score}
                    </div>
                  </Popup>
                </Marker>
              ))}
              {/* City weather overlays */}
              {cities.map((city) => {
                const col = city.floodRisk === "Critical" ? "#ef4444"
                  : city.floodRisk === "High" ? "#f97316"
                  : city.floodRisk === "Moderate" ? "#eab308"
                  : "#22c55e";
                return (
                  <Circle
                    key={city.name}
                    center={[city.lat, city.lng]}
                    radius={city.rainfall > 0 ? city.rainfall * 4000 + 60000 : 50000}
                    pathOptions={{ color: col, fillColor: col, fillOpacity: 0.08, weight: 1, opacity: 0.4 }}
                  />
                );
              })}
            </MapContainer>
          </div>

          {/* Bottom panels */}
          <div className="border-t border-white/10 bg-[hsl(222,47%,9%)] px-4 py-3">
            <div className="flex gap-4 overflow-x-auto scrollbar-none">
              {/* Rainfall bar */}
              <div className="shrink-0">
                <div className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-2">
                  <CloudRain size={9} className="inline mr-1 text-blue-400" />Rainfall (mm)
                </div>
                <div className="flex items-end gap-1 h-10">
                  {cities.map((c) => {
                    const h = Math.min(100, (c.rainfall / 60) * 100);
                    const col = c.floodRisk === "Critical" ? "#ef4444" : c.floodRisk === "High" ? "#f97316" : c.floodRisk === "Moderate" ? "#eab308" : "#22c55e";
                    return (
                      <div key={c.name} className="flex flex-col items-center gap-0.5" title={`${c.name}: ${c.rainfall.toFixed(1)}mm`}>
                        <div style={{ height: `${Math.max(4, h)}%`, background: col, minHeight: 4 }} className="w-4 rounded-t transition-all duration-500" />
                        <div className="text-[8px] text-white/30 truncate w-8 text-center">{c.name.slice(0, 3)}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Wind speed */}
              <div className="shrink-0">
                <div className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-2">
                  <Wind size={9} className="inline mr-1 text-teal-400" />Wind (km/h)
                </div>
                <div className="flex items-center gap-2">
                  {cities.slice(0, 4).map((c) => (
                    <div key={c.name} className="flex flex-col items-center">
                      <ArrowUp
                        size={16}
                        className="text-teal-400"
                        style={{ opacity: Math.min(1, c.windSpeed / 40 + 0.2) }}
                      />
                      <div className="text-[9px] text-white font-bold">{c.windSpeed}</div>
                      <div className="text-[8px] text-white/30">{c.name.slice(0, 3)}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active alerts */}
              <div className="flex-1 min-w-40">
                <div className="text-[9px] font-bold text-white/40 uppercase tracking-wider mb-2">
                  <Zap size={9} className="inline mr-1 text-yellow-400" />Active Weather Alerts
                </div>
                <div className="flex flex-wrap gap-1">
                  {criticalCities.length === 0 ? (
                    <div className="flex items-center gap-1.5 text-[10px] text-emerald-400">
                      <CircleCheck size={11} />
                      All regions weather-stable
                    </div>
                  ) : (
                    criticalCities.map((c) => (
                      <div key={c.name} className="text-[9px] bg-red-900/40 border border-red-700/40 text-red-300 px-2 py-0.5 rounded-full">
                        ⚠ {c.name}: {c.floodRisk} risk
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* System status */}
              <div className="shrink-0 flex flex-col justify-center gap-1">
                {[
                  { label: t("system_online"), ok: true },
                  { label: "Open-Meteo Feed: Live", ok: !loading },
                  { label: `${villages.length} villages tracked`, ok: true },
                ].map((s) => (
                  <div key={s.label} className="flex items-center gap-1.5 text-[9px]">
                    <div className={`w-1.5 h-1.5 rounded-full ${s.ok ? "bg-emerald-400 animate-pulse" : "bg-yellow-400"}`} />
                    <span className="text-white/50">{s.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
