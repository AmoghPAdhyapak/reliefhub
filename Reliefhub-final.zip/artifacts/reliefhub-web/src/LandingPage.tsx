import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Shield, AlertTriangle, Users, Package, Radio,
  ArrowRight, ChevronRight, Zap, Globe, Activity,
  MapPin, BarChart3, Layers, CheckCircle, Heart
} from "lucide-react";
import { useLanguage } from "./context/LanguageContext";

function useCounter(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const started = useRef(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        const steps = 60;
        const inc = target / steps;
        let cur = 0;
        const iv = setInterval(() => {
          cur += inc;
          if (cur >= target) { setCount(target); clearInterval(iv); }
          else setCount(Math.floor(cur));
        }, duration / steps);
      }
    });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, duration]);

  return { count, ref };
}

function StatCounter({ value, label, suffix = "" }: { value: number; label: string; suffix?: string }) {
  const { count, ref } = useCounter(value);
  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl font-black text-white">
        {count.toLocaleString()}{suffix}
      </div>
      <div className="text-[hsl(142,60%,65%)] text-xs font-semibold mt-1 uppercase tracking-wider">{label}</div>
    </div>
  );
}

export default function LandingPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const flowSteps = [
    { icon: <AlertTriangle size={18} />, label: t("flow_citizen"), color: "bg-red-500" },
    { icon: <BarChart3 size={18} />, label: t("flow_priority"), color: "bg-orange-500" },
    { icon: <Users size={18} />, label: t("flow_ngo"), color: "bg-blue-500" },
    { icon: <MapPin size={18} />, label: t("flow_route"), color: "bg-violet-500" },
    { icon: <Package size={18} />, label: t("flow_delivery"), color: "bg-emerald-500" },
  ];

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      {/* ── Hero ─────────────────────────────────────────────────── */}
      <section className="relative bg-[hsl(222,47%,11%)] text-white overflow-hidden">
        {/* Background mesh */}
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 25% 25%, hsl(142,76%,36%) 0%, transparent 50%), radial-gradient(circle at 75% 75%, hsl(238,83%,57%) 0%, transparent 50%)"
        }} />
        <div className="absolute inset-0" style={{
          backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "40px 40px"
        }} />

        <div className="relative max-w-5xl mx-auto px-4 pt-20 pb-24 text-center">
          {/* Logo badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 px-4 py-2 rounded-full text-xs font-semibold mb-8 backdrop-blur-sm">
            <div className="w-2 h-2 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
            AI-Powered National Disaster Response Platform
          </div>

          {/* Shield + Name */}
          <div className="flex flex-col items-center gap-4 mb-6">
            <div style={{ filter: "drop-shadow(0 0 40px rgba(22,163,74,0.5))" }}>
              <svg width="80" height="80" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M48 4L12 20V48C12 67.2 28 83.6 48 92C68 83.6 84 67.2 84 48V20L48 4Z" fill="hsl(142,76%,36%)" />
                <path d="M48 18L24 28V48C24 61.2 34.4 72.6 48 78C61.6 72.6 72 61.2 72 48V28L48 18Z" fill="hsl(142,76%,28%)" />
                <text x="48" y="55" textAnchor="middle" fill="white" fontSize="22" fontWeight="800" fontFamily="system-ui">RH</text>
              </svg>
            </div>
            <h1 className="text-5xl sm:text-6xl font-black tracking-[0.12em] text-white">
              RELIEFHUB
            </h1>
          </div>

          <p className="text-[hsl(142,60%,65%)] text-xl font-semibold mb-3">
            {t("tagline")}
          </p>
          <p className="text-white/60 text-base mb-10 max-w-xl mx-auto leading-relaxed">
            {t("hero_subtitle")}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => navigate("/help")}
              className="flex items-center justify-center gap-2 bg-[hsl(142,76%,36%)] hover:bg-[hsl(142,76%,32%)] text-white px-8 py-4 rounded-xl font-bold text-sm transition-all shadow-lg shadow-emerald-900/30 hover:shadow-emerald-900/50 hover:-translate-y-0.5"
            >
              <AlertTriangle size={16} />
              {t("btn_get_help")}
            </button>
            <button
              onClick={() => navigate("/testing")}
              className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white px-8 py-4 rounded-xl font-bold text-sm transition-all backdrop-blur-sm hover:-translate-y-0.5"
            >
              <Zap size={16} />
              {t("btn_view_demo")}
            </button>
            <button
              onClick={() => navigate("/dashboard")}
              className="flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white px-8 py-4 rounded-xl font-bold text-sm transition-all hover:-translate-y-0.5"
            >
              <Radio size={16} />
              Live Dashboard
            </button>
          </div>
        </div>
      </section>

      {/* ── Stats bar ──────────────────────────────────────────── */}
      <section className="bg-[hsl(142,76%,28%)] py-10">
        <div className="max-w-4xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-8">
          <StatCounter value={248} label={t("villages_protected")} />
          <StatCounter value={42600} label={t("families_helped")} />
          <StatCounter value={18400} label={t("resources_delivered")} />
          <StatCounter value={34} label={t("ngos_coordinated")} />
        </div>
      </section>

      {/* ── 3 Cards ────────────────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-black text-[hsl(222,47%,11%)] mb-2">
            How ReliefHub Works
          </h2>
          <p className="text-[hsl(215,16%,47%)] text-sm">Government-level trust. Startup-level polish.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              icon: <AlertTriangle size={28} />,
              iconBg: "bg-red-100",
              iconColor: "text-red-600",
              title: t("card_help_title"),
              desc: t("card_help_desc"),
              cta: t("btn_get_help"),
              action: () => navigate("/help"),
              accent: "hover:border-red-300 hover:shadow-red-100",
              ctaStyle: "bg-red-600 hover:bg-red-700 text-white",
            },
            {
              icon: <Layers size={28} />,
              iconBg: "bg-blue-100",
              iconColor: "text-blue-600",
              title: t("card_coord_title"),
              desc: t("card_coord_desc"),
              cta: "Open Dashboard",
              action: () => navigate("/dashboard"),
              accent: "hover:border-blue-300 hover:shadow-blue-100",
              ctaStyle: "bg-blue-600 hover:bg-blue-700 text-white",
            },
            {
              icon: <Zap size={28} />,
              iconBg: "bg-emerald-100",
              iconColor: "text-emerald-600",
              title: t("card_demo_title"),
              desc: t("card_demo_desc"),
              cta: t("btn_view_demo"),
              action: () => navigate("/testing"),
              accent: "hover:border-emerald-300 hover:shadow-emerald-100",
              ctaStyle: "bg-emerald-600 hover:bg-emerald-700 text-white",
            },
          ].map((card) => (
            <div
              key={card.title}
              className={`bg-white border-2 border-[hsl(214,32%,91%)] rounded-2xl p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${card.accent} flex flex-col`}
            >
              <div className={`inline-flex p-3 rounded-xl ${card.iconBg} ${card.iconColor} mb-4 self-start`}>
                {card.icon}
              </div>
              <h3 className="font-black text-[hsl(222,47%,11%)] text-sm uppercase tracking-wider mb-2">{card.title}</h3>
              <p className="text-[hsl(215,16%,47%)] text-sm leading-relaxed flex-1 mb-5">{card.desc}</p>
              <button
                onClick={card.action}
                className={`flex items-center justify-center gap-2 w-full py-2.5 rounded-lg font-bold text-xs transition-all ${card.ctaStyle}`}
              >
                {card.cta}
                <ChevronRight size={14} />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* ── Workflow flow ──────────────────────────────────────── */}
      <section className="bg-[hsl(210,40%,98%)] py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-black text-[hsl(222,47%,11%)] mb-2">
              From SOS to Safety in 5 Steps
            </h2>
            <p className="text-[hsl(215,16%,47%)] text-sm">Understandable within 10 seconds</p>
          </div>

          {/* Horizontal flow */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-0">
            {flowSteps.map((step, i) => (
              <div key={i} className="flex flex-col sm:flex-row items-center gap-0">
                <div className="flex flex-col items-center">
                  <div className={`w-14 h-14 rounded-2xl ${step.color} flex items-center justify-center text-white shadow-md`}>
                    {step.icon}
                  </div>
                  <div className="text-[10px] font-bold text-[hsl(222,47%,11%)] text-center mt-2 max-w-[90px] leading-tight">
                    {step.label}
                  </div>
                </div>
                {i < flowSteps.length - 1 && (
                  <div className="flex sm:flex-row flex-col items-center">
                    <div className="w-px h-6 sm:w-12 sm:h-px bg-[hsl(214,32%,91%)] mx-1" />
                    <ArrowRight size={14} className="text-[hsl(215,16%,47%)] hidden sm:block" />
                    <ArrowRight size={14} className="text-[hsl(215,16%,47%)] sm:hidden rotate-90" />
                    <div className="w-px h-6 sm:w-4 sm:h-px bg-[hsl(214,32%,91%)] mx-1" />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Story cards below */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { icon: <Heart size={16} />, title: "SOS Received", body: "Citizen reports emergency via GPS location. AI immediately calculates priority score.", color: "border-red-200 bg-red-50", iconColor: "text-red-600" },
              { icon: <CheckCircle size={16} />, title: "NGO Assigned", body: "Optimal NGO dispatched based on location, capacity, and current workload.", color: "border-blue-200 bg-blue-50", iconColor: "text-blue-600" },
              { icon: <Package size={16} />, title: "Aid Delivered", body: "Real-time tracking. Village status updates from Critical → Covered.", color: "border-emerald-200 bg-emerald-50", iconColor: "text-emerald-600" },
            ].map((s) => (
              <div key={s.title} className={`rounded-xl border p-4 ${s.color}`}>
                <div className={`flex items-center gap-2 font-bold text-sm mb-2 ${s.iconColor}`}>
                  {s.icon} {s.title}
                </div>
                <p className="text-xs text-[hsl(215,16%,47%)] leading-relaxed">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Feature highlights ─────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <h2 className="text-2xl font-black text-[hsl(222,47%,11%)] text-center mb-10">
          Platform Features
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: <BarChart3 size={20} />, label: "Priority Engine", desc: "Multi-factor AI scoring" },
            { icon: <MapPin size={20} />, label: "Live Map", desc: "Real-time village tracking" },
            { icon: <Radio size={20} />, label: "Radar", desc: "Weather & threat overview" },
            { icon: <Activity size={20} />, label: "NGO Feed", desc: "Live activity timeline" },
          ].map((f) => (
            <div key={f.label} className="bg-white border border-[hsl(214,32%,91%)] rounded-xl p-4 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="bg-[hsl(142,76%,93%)] p-2.5 rounded-lg inline-flex text-[hsl(142,76%,36%)] mb-3">
                {f.icon}
              </div>
              <div className="text-xs font-bold text-[hsl(222,47%,11%)]">{f.label}</div>
              <div className="text-[10px] text-[hsl(215,16%,47%)] mt-0.5">{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA Banner ─────────────────────────────────────────── */}
      <section className="bg-[hsl(222,47%,11%)] py-12 px-4 text-center">
        <div className="max-w-xl mx-auto">
          <h2 className="text-2xl font-black text-white mb-3">Ready to coordinate relief?</h2>
          <p className="text-white/60 text-sm mb-6">Experience the full platform with live disaster simulation</p>
          <button
            onClick={() => navigate("/testing")}
            className="inline-flex items-center gap-2 bg-[hsl(142,76%,36%)] hover:bg-[hsl(142,76%,32%)] text-white px-8 py-4 rounded-xl font-bold text-sm transition-all shadow-lg"
          >
            <Zap size={16} />
            {t("btn_view_demo")}
            <ArrowRight size={16} />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[hsl(214,32%,91%)] py-6 px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <svg width="20" height="20" viewBox="0 0 96 96" fill="none"><path d="M48 4L12 20V48C12 67.2 28 83.6 48 92C68 83.6 84 67.2 84 48V20L48 4Z" fill="hsl(142,76%,36%)" /><text x="48" y="58" textAnchor="middle" fill="white" fontSize="26" fontWeight="800" fontFamily="system-ui">RH</text></svg>
          <span className="text-xs font-bold text-[hsl(222,47%,11%)]">RELIEFHUB</span>
        </div>
        <p className="text-[10px] text-[hsl(215,16%,47%)]">AI-Powered Disaster Relief Coordination Platform · Hackathon Demo</p>
      </footer>
    </div>
  );
}
