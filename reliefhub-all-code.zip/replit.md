# ReliefHub

AI-Powered Disaster Relief Coordination Platform — hackathon MVP backend.

## Run & Operate

- Server starts automatically via the workflow
- Manual: `cd artifacts/api-server && uvicorn main:app --host 0.0.0.0 --port 8080 --reload`
- Test all endpoints: `bash artifacts/api-server/api_test.sh`
- Interactive docs: `/api/docs` (FastAPI Swagger UI)

## Stack

- Python + FastAPI 0.110.0
- Uvicorn 0.28.0
- Pydantic 2.6.4
- In-memory data (no database)
- CORS open to all origins (hackathon mode)

## Where things live

- `artifacts/api-server/main.py` — entire FastAPI app (schemas, routes, in-memory store)
- `artifacts/api-server/requirements.txt` — pip dependencies
- `artifacts/api-server/api_test.sh` — curl test harness for judge demo

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/dashboard` | Mission stats (villages, families, NGOs, items) |
| GET | `/api/v1/villages` | Full village registry |
| POST | `/api/v1/sos` | Submit emergency SOS request |
| POST | `/api/v1/allocate` | AI resource allocation recommendation |
| POST | `/api/v1/duplicate-check` | Duplicate supply detection |
| POST | `/api/v1/chat` | AI assistant (mock + Gemini placeholder) |
| GET | `/api/healthz` | Health check |

## Architecture decisions

- All data lives in Python lists/dicts in memory — no DB, restarts reset state (intentional for hackathon)
- Rule-based logic for allocation and duplicate detection — Gemini hook is stubbed and activates if `GEMINI_API_KEY` env var is set
- CORS wildcard configured so Lovable frontend can connect immediately

## Product

ReliefHub coordinates disaster relief across villages and NGOs. It tracks which villages need aid, prevents duplicate deliveries, recommends where to send resources, and answers natural language queries about the situation.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Data resets on server restart (in-memory by design)
- Frontend should point to `/api/v1/` base URL
- Gemini AI activates automatically if `GEMINI_API_KEY` is set as an environment variable
