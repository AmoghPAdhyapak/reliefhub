import { useState, useEffect, useRef, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Shield, MapPin, AlertTriangle, CheckCircle, CircleDot, Send,
  ChevronRight, Package, Users, HeartPulse, Droplets, Tent,
  Thermometer, TrendingUp, Activity, BarChart3, Info, X, ChevronDown,
  Clock, FileText, Megaphone, ArrowRight, AlertOctagon, CircleCheck,
  Layers, Radio, Navigation, Crosshair, Target, Route, MapPinned,
  Maximize2, Minimize2, List, Filter, FlaskConical, RefreshCcw, Zap, Bell
} from "lucide-react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap, Circle } from "react-leaflet";
import L from "leaflet";
import { Routes, Route as RRRoute } from "react-router-dom";
import NavBar from "./components/NavBar";
import RadarPage from "./pages/RadarPage";
import LandingPage from "./LandingPage";
import SplashScreen from "./SplashScreen";
import LanguageSelection from "./LanguageSelection";
import HelpFlow from "./pages/HelpFlow";
import { LanguageProvider } from "./context/LanguageContext";

const queryClient = new QueryClient();

// ── API helpers ───────────────────────────────────────────────────────
const API_BASE = "/api/v1";

async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function apiPost<T>(path: string, body: object): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// ── Types ─────────────────────────────────────────────────────────────
interface PriorityBreakdown {
  geographical_score: number;
  volunteer_report_score: number;
  ngo_report_score: number;
  crowd_verification_score: number;
  disaster_severity_score: number;
  previous_aid_impact: number;
  final_priority_score: number;
  classification: string;
}

interface Village {
  id: string;
  name: string;
  status: "critical" | "moderate" | "covered";
  needs: string;
  families: number;
  metrics: string;
  trackingDemand: string;
  position: { lat: number; lng: number };
  aid_received: number;
  severity_score: number;
  need_score: number;
  state: string;
  priority_breakdown: PriorityBreakdown;
}

interface DashboardData {
  villages_affected: number;
  families_helped: number;
  active_ngos: number;
  items_delivered: number;
}

interface SupplyData {
  food_kits: { total: number; in_transit: number; delivered: number };
  medicines: { total: number; in_transit: number; delivered: number };
  water: { total: number; in_transit: number; delivered: number };
  blankets: { total: number; in_transit: number; delivered: number };
  tents: { total: number; in_transit: number; delivered: number };
}

interface ChatResponse {
  response: string;
}

interface DuplicateResponse {
  duplicate: boolean;
  message: string;
  suggested_village?: string;
  priority_breakdown?: PriorityBreakdown;
}

interface SosResponse {
  success: boolean;
  message: string;
  inserted_id: string;
  calculated_priority: string;
  priority_breakdown: PriorityBreakdown;
}

interface AnalyticsData {
  critical: number;
  moderate: number;
  covered: number;
  total: number;
}

interface SosMarker {
  id: string;
  lat: number;
  lng: number;
  village: string;
  timestamp: string;
  families: number;
}

interface ActivityItem {
  timestamp: string;
  actor: string;
  action: string;
  village: string;
  details: string;
}

interface ActivitiesResponse {
  activities: ActivityItem[];
}

interface TestingVillagesResponse {
  simulation_mode: boolean;
  scenario: string;
  villages: Village[];
}

// ── Status helpers ────────────────────────────────────────────────────
const statusColors = {
  critical: "bg-red-500 text-white",
  moderate: "bg-amber-500 text-white",
  covered: "bg-emerald-500 text-white",
};

const statusBgColors = {
  critical: "bg-red-50 border-red-200 text-red-800",
  moderate: "bg-amber-50 border-amber-200 text-amber-800",
  covered: "bg-emerald-50 border-emerald-200 text-emerald-800",
};

// ── KPI Card ─────────────────────────────────────────────────────────
function KpiCard({
  label,
  value,
  icon,
  accent,
  subtext,
}: {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  accent: string;
  subtext?: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold text-[hsl(215,16%,47%)] uppercase tracking-wider">
          {label}
        </span>
        <div className={`p-2 rounded-lg ${accent}`}>{icon}</div>
      </div>
      <div className="text-3xl font-bold text-[hsl(222,47%,11%)]">{value}</div>
      {subtext && <div className="text-[10px] text-[hsl(215,16%,47%)] mt-1">{subtext}</div>}
    </div>
  );
}

// ── Priority Engine Panel ─────────────────────────────────────────────
function PriorityEnginePanel({
  village,
  onClose,
  isDefault = false,
}: {
  village: Village | null;
  onClose: () => void;
  isDefault?: boolean;
}) {
  if (!village) {
    return (
      <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm animate-fade-in">
        <div className="flex items-center gap-2 mb-3">
          <div className="bg-[hsl(238,100%,96%)] p-2 rounded-lg">
            <BarChart3 size={16} className="text-[hsl(238,83%,57%)]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">Priority Engine</h3>
            <p className="text-[10px] text-[hsl(215,16%,47%)]">Multi-factor scoring analysis</p>
          </div>
        </div>
        <div className="flex flex-col items-center py-5 gap-2 text-center">
          <div className="bg-[hsl(210,40%,96%)] p-3 rounded-full">
            <MapPin size={20} className="text-[hsl(215,16%,47%)]" />
          </div>
          <p className="text-xs text-[hsl(215,16%,47%)]">Click a village marker on the map<br />to see its priority breakdown</p>
        </div>
      </div>
    );
  }
  const pb = village.priority_breakdown;
  const factors = [
    { label: "Geographical Assignment", value: pb.geographical_score, max: 30, color: "bg-blue-500" },
    { label: "Volunteer Report", value: pb.volunteer_report_score, max: 25, color: "bg-emerald-500" },
    { label: "NGO Report", value: pb.ngo_report_score, max: 15, color: "bg-violet-500" },
    { label: "Crowd Verification", value: pb.crowd_verification_score, max: 20, color: "bg-amber-500" },
    { label: "Disaster Severity", value: pb.disaster_severity_score, max: 30, color: "bg-red-500" },
    { label: "Previous Aid Impact", value: Math.abs(pb.previous_aid_impact), max: 20, color: "bg-slate-500" },
  ];

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="bg-[hsl(238,100%,96%)] p-2 rounded-lg">
            <BarChart3 size={16} className="text-[hsl(238,83%,57%)]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">Priority Engine</h3>
            <p className="text-[10px] text-[hsl(215,16%,47%)]">Multi-factor scoring analysis</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isDefault && (
            <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
              Top Priority
            </span>
          )}
          {!isDefault && (
            <button onClick={onClose} className="p-1 hover:bg-[hsl(210,40%,96%)] rounded-lg transition-colors">
              <X size={14} className="text-[hsl(215,16%,47%)]" />
            </button>
          )}
        </div>
      </div>

      <div className="mb-4">
        <div className="text-xs font-semibold text-[hsl(222,47%,11%)] mb-1">{village.name}</div>
        <div className="text-[10px] text-[hsl(215,16%,47%)] mb-3">{village.needs} · {village.families} families</div>
      </div>

      <div className="flex flex-col gap-2.5 mb-4">
        {factors.map((f) => (
          <div key={f.label}>
            <div className="flex justify-between text-[10px] font-medium text-[hsl(222,47%,11%)] mb-1">
              <span>{f.label}</span>
              <span>{f.value.toFixed(1)} / {f.max}</span>
            </div>
            <div className="h-[6px] bg-[hsl(210,40%,96%)] rounded-full overflow-hidden">
              <div className={`h-full rounded-full ${f.color} transition-all duration-700`} style={{ width: `${Math.min((f.value / f.max) * 100, 100)}%` }} />
            </div>
          </div>
        ))}
      </div>

      <div className="border-t border-[hsl(214,32%,91%)] pt-3 flex items-center justify-between">
        <div>
          <div className="text-[10px] text-[hsl(215,16%,47%)] uppercase tracking-wider font-semibold">Final Score</div>
          <div className="text-xl font-bold text-[hsl(222,47%,11%)]">{pb.final_priority_score}</div>
        </div>
        <div className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
          pb.classification === "critical"
            ? "bg-red-500 text-white"
            : pb.classification === "moderate"
            ? "bg-amber-500 text-white"
            : "bg-emerald-500 text-white"
        }`}>
          {pb.classification}
        </div>
      </div>
    </div>
  );
}

// ── Map Panel ──────────────────────────────────────────────────────────
function MapPanel({
  villages,
  onVillageSelect,
  selectedVillage,
  selectedState,
  sosMarkers = [],
}: {
  villages: Village[];
  onVillageSelect: (v: Village | null) => void;
  selectedVillage: Village | null;
  selectedState: string;
  sosMarkers?: SosMarker[];
}) {
  const [userPos, setUserPos] = useState<{ lat: number; lng: number } | null>(null);
  const [geoError, setGeoError] = useState("");
  const [route, setRoute] = useState<[number, number][] | null>(null);
  const [routeInfo, setRouteInfo] = useState<{ distance: string; duration: string } | null>(null);
  const [routeLoading, setRouteLoading] = useState(false);
  const [navigatingTo, setNavigatingTo] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [filter, setFilter] = useState<"all" | "critical" | "moderate" | "covered">("all");
  const [panTarget, setPanTarget] = useState<{ lat: number; lng: number } | null>(null);
  const prevSosCountRef = useRef(sosMarkers.length);

  const defaultCenter: [number, number] = [15.5, 78.5];

  useEffect(() => {
    if (sosMarkers.length > prevSosCountRef.current) {
      const latest = sosMarkers[sosMarkers.length - 1];
      setPanTarget({ lat: latest.lat, lng: latest.lng });
    }
    prevSosCountRef.current = sosMarkers.length;
  }, [sosMarkers]);

  useEffect(() => {
    if (!navigator.geolocation) {
      setGeoError("Geolocation not supported");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      },
      (err) => {
        setGeoError("Location access denied");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }, []);

  const getMarkerIcon = (status: string, isHighlighted: boolean) => {
    const color = status === "critical" ? "#EF4444" : status === "moderate" ? "#F59E0B" : "#22C55E";
    const ring = isHighlighted ? "0 0 0 4px rgba(37,99,235,0.5)," : "";
    return L.divIcon({
      className: "custom-marker",
      html: `<div style="width:24px;height:24px;border-radius:50%;background:${color};border:3px solid white;box-shadow:${ring}0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
        <span style="font-size:10px;font-weight:bold;color:white;">${status === "critical" ? "!" : status === "moderate" ? "~" : "&#10003;"}</span>
      </div>`,
      iconSize: isHighlighted ? [32, 32] : [24, 24],
      iconAnchor: isHighlighted ? [16, 16] : [12, 12],
      popupAnchor: [0, -12],
    });
  };

  const userIcon = L.divIcon({
    className: "user-marker",
    html: `<div style="width:28px;height:28px;border-radius:50%;background:#2563EB;border:3px solid white;box-shadow:0 2px 10px rgba(37,99,235,0.5);display:flex;align-items:center;justify-content:center;">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4m-10-10h4m12 0h4"/></svg>
    </div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });

  const sosIcon = L.divIcon({
    className: "sos-marker",
    html: `<div style="position:relative;width:36px;height:36px;display:flex;align-items:center;justify-content:center;">
      <div style="position:absolute;width:36px;height:36px;border-radius:50%;background:rgba(239,68,68,0.25);animation:ping 1.2s cubic-bezier(0,0,0.2,1) infinite;"></div>
      <div style="position:absolute;width:28px;height:28px;border-radius:50%;background:rgba(239,68,68,0.35);animation:ping 1.2s cubic-bezier(0,0,0.2,1) infinite 0.3s;"></div>
      <div style="position:relative;width:22px;height:22px;border-radius:50%;background:#DC2626;border:3px solid white;box-shadow:0 2px 10px rgba(220,38,38,0.6);display:flex;align-items:center;justify-content:center;">
        <span style="font-size:9px;font-weight:900;color:white;line-height:1;">SOS</span>
      </div>
    </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18],
  });

  async function calculateRoute(village: Village) {
    if (!userPos) {
      alert("Please enable location access first");
      return;
    }
    setRouteLoading(true);
    setNavigatingTo(village.id);
    setRoute(null);
    setRouteInfo(null);
    try {
      const R = 6371;
      const dLat = (village.position.lat - userPos.lat) * Math.PI / 180;
      const dLon = (village.position.lng - userPos.lng) * Math.PI / 180;
      const a = Math.sin(dLat/2)*Math.sin(dLat/2) + Math.cos(userPos.lat*Math.PI/180)*Math.cos(village.position.lat*Math.PI/180)*Math.sin(dLon/2)*Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const dist = R * c;
      const dur = (dist / 40) * 60;
      setRoute([[userPos.lat, userPos.lng], [village.position.lat, village.position.lng]]);
      setRouteInfo({
        distance: `${dist.toFixed(1)} km (straight line)`,
        duration: `${Math.round(dur)} min`,
      });
    } finally {
      setRouteLoading(false);
    }
  }

  function MapCenterer({ center }: { center: [number, number] }) {
    const map = useMap();
    useEffect(() => {
      map.setView(center, map.getZoom());
    }, [center, map]);
    return null;
  }

  function SosPanner({ target }: { target: { lat: number; lng: number } | null }) {
    const map = useMap();
    useEffect(() => {
      if (target) {
        map.flyTo([target.lat, target.lng], 13, { animate: true, duration: 1.5 });
      }
    }, [target, map]);
    return null;
  }

  const filteredVillages = filter === "all" ? villages : villages.filter(v => v.status === filter);

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-[hsl(214,32%,91%)]">
        <div className="flex items-center gap-2">
          <div className="bg-[hsl(210,40%,96%)] p-2 rounded-lg">
            <MapPin size={16} className="text-[hsl(222,47%,11%)]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">Live Relief Map</h3>
            <p className="text-[10px] text-[hsl(215,16%,47%)]">{villages.length} villages monitored</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            {(["all", "critical", "moderate", "covered"] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-2 py-1 text-[10px] font-semibold rounded-md transition-colors ${
                  filter === f
                    ? f === "all" ? "bg-[hsl(222,47%,11%)] text-white"
                      : f === "critical" ? "bg-red-500 text-white"
                      : f === "moderate" ? "bg-amber-500 text-white"
                      : "bg-emerald-500 text-white"
                    : "bg-[hsl(210,40%,96%)] text-[hsl(215,16%,47%)] hover:bg-[hsl(210,40%,92%)]"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1.5 hover:bg-[hsl(210,40%,96%)] rounded-lg transition-colors"
          >
            {expanded ? <Minimize2 size={14} className="text-[hsl(215,16%,47%)]" /> : <Maximize2 size={14} className="text-[hsl(215,16%,47%)]" />}
          </button>
        </div>
      </div>

      {routeInfo && (
        <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 flex items-center gap-3 text-xs">
          <Route size={12} className="text-blue-600 shrink-0" />
          <span className="text-blue-700 font-semibold">{routeInfo.distance}</span>
          <span className="text-blue-600">·</span>
          <span className="text-blue-600">{routeInfo.duration} drive</span>
          <button onClick={() => { setRoute(null); setRouteInfo(null); setNavigatingTo(null); }} className="ml-auto text-blue-500 hover:text-blue-700">
            <X size={12} />
          </button>
        </div>
      )}

      <MapContainer
        center={userPos ? [userPos.lat, userPos.lng] : defaultCenter}
        zoom={userPos ? 10 : 6}
        style={{ height: expanded ? "520px" : "320px", width: "100%" }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <SosPanner target={panTarget} />

        {userPos && (
          <>
            <Marker position={[userPos.lat, userPos.lng]} icon={userIcon}>
              <Popup>
                <div className="text-xs font-semibold">Your Position</div>
                <div className="text-[10px] text-[hsl(215,16%,47%)]">{userPos.lat.toFixed(4)}°N, {userPos.lng.toFixed(4)}°E</div>
              </Popup>
            </Marker>
            <MapCenterer center={[userPos.lat, userPos.lng]} />
          </>
        )}

        {filteredVillages.map((v) => {
          const isHighlighted = !!selectedState && v.state === selectedState;
          return (
            <Marker
              key={v.id}
              position={[v.position.lat, v.position.lng]}
              icon={getMarkerIcon(v.status, isHighlighted)}
              eventHandlers={{
                click: () => {
                  onVillageSelect(v);
                  setRoute(null);
                  setRouteInfo(null);
                  setNavigatingTo(null);
                },
              }}
            >
              <Popup>
                <div className="min-w-[200px]">
                  <div className="font-semibold text-sm text-[hsl(222,47%,11%)] mb-1">{v.name}</div>
                  <div className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase text-white mb-2 ${
                    v.status === "critical" ? "bg-red-500" : v.status === "moderate" ? "bg-amber-500" : "bg-emerald-500"
                  }`}>
                    {v.status}
                  </div>
                  <div className="text-[10px] text-[hsl(215,16%,47%)] space-y-1">
                    <div><strong>State:</strong> {v.state}</div>
                    <div><strong>Priority Score:</strong> {v.priority_breakdown.final_priority_score}</div>
                    <div><strong>Families:</strong> {v.families.toLocaleString()}</div>
                    <div><strong>Needs:</strong> {v.needs}</div>
                    <div><strong>Aid Received:</strong> {v.aid_received}%</div>
                  </div>
                  {v.status === "critical" && (
                    <button
                      className="mt-2 w-full bg-[hsl(142,76%,36%)] text-white text-[10px] font-bold py-1.5 rounded hover:opacity-90 transition-opacity flex items-center justify-center gap-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        calculateRoute(v);
                      }}
                      disabled={routeLoading}
                    >
                      {routeLoading && navigatingTo === v.id ? (
                        <span>Calculating...</span>
                      ) : (
                        <>
                          <Navigation size={12} />
                          Navigate to Village
                        </>
                      )}
                    </button>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}

        {selectedState && filteredVillages
          .filter((v) => v.state === selectedState)
          .map((v) => (
            <Circle
              key={`ring-${v.id}`}
              center={[v.position.lat, v.position.lng]}
              radius={8000}
              pathOptions={{
                color: "#2563EB",
                fillColor: "#2563EB",
                fillOpacity: 0.08,
                weight: 2,
                dashArray: "6, 6",
              }}
            />
          ))}

        {route && (
          <Polyline
            positions={route}
            color="#2563EB"
            weight={4}
            opacity={0.7}
            dashArray={route.length > 2 ? undefined : "10, 10"}
          />
        )}

        {sosMarkers.map((sm) => (
          <Marker
            key={`sos-${sm.id}`}
            position={[sm.lat, sm.lng]}
            icon={sosIcon}
          >
            <Popup>
              <div className="min-w-[200px]">
                <div className="flex items-center gap-1.5 mb-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="font-bold text-sm text-red-700">EMERGENCY SOS</span>
                </div>
                <div className="text-[10px] text-[hsl(215,16%,47%)] space-y-1 mb-2">
                  <div><strong>Location:</strong> {sm.lat.toFixed(4)}°N, {sm.lng.toFixed(4)}°E</div>
                  <div><strong>Sector:</strong> {sm.village}</div>
                  <div><strong>Families:</strong> {sm.families.toLocaleString()}</div>
                  <div><strong>Time:</strong> {sm.timestamp}</div>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

// ── Supply Panel ──────────────────────────────────────────────────────
function SupplyPanel({ supply }: { supply: SupplyData | null }) {
  if (!supply) return null;
  const items = [
    { label: "Food Kits", icon: <Package size={14} />, data: supply.food_kits, color: "text-emerald-600 bg-emerald-50" },
    { label: "Medicines", icon: <HeartPulse size={14} />, data: supply.medicines, color: "text-red-600 bg-red-50" },
    { label: "Water", icon: <Droplets size={14} />, data: supply.water, color: "text-blue-600 bg-blue-50" },
    { label: "Blankets", icon: <Tent size={14} />, data: supply.blankets, color: "text-violet-600 bg-violet-50" },
    { label: "Tents", icon: <Thermometer size={14} />, data: supply.tents, color: "text-amber-600 bg-amber-50" },
  ];
  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <div className="bg-[hsl(210,40%,96%)] p-2 rounded-lg">
          <Package size={16} className="text-[hsl(222,47%,11%)]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">Supply Chain Tracker</h3>
          <p className="text-[10px] text-[hsl(215,16%,47%)]">Real-time inventory status</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-2">
        {items.map(({ label, icon, data, color }) => (
          <div key={label} className="flex items-center gap-3 p-2.5 rounded-lg bg-[hsl(210,40%,98%)] border border-[hsl(214,32%,91%)]">
            <div className={`p-2 rounded-lg ${color}`}>{icon}</div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-[hsl(222,47%,11%)]">{label}</div>
              <div className="flex gap-3 mt-0.5">
                <span className="text-[10px] text-[hsl(215,16%,47%)]">Total: <strong>{data.total}</strong></span>
                <span className="text-[10px] text-amber-600">In Transit: <strong>{data.in_transit}</strong></span>
                <span className="text-[10px] text-emerald-600">Delivered: <strong>{data.delivered}</strong></span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── AI Allocation Panel ───────────────────────────────────────────────
const STATES = [
  "All States", "Tamil Nadu", "Andhra Pradesh", "Bihar", "Odisha",
  "Kerala", "Gujarat", "Maharashtra", "West Bengal", "Assam",
  "Rajasthan", "Madhya Pradesh", "Delhi"
];

function AiPanel({
  villages,
  onAction,
  selectedState,
  onStateChange,
  apiBase = "",
}: {
  villages: Village[];
  onAction: () => void;
  selectedState: string;
  onStateChange: (s: string) => void;
  apiBase?: string;
}) {
  const [resource, setResource] = useState("Food Kits");
  const [qty, setQty] = useState(50);
  const [allocResult, setAllocResult] = useState<{ recommended_village: string; reason: string; priority_score_calculated: number; priority_breakdown: PriorityBreakdown } | null>(null);
  const [allocLoading, setAllocLoading] = useState(false);

  const [dupVillage, setDupVillage] = useState("");
  const [dupResource, setDupResource] = useState("Food Kits");
  const [dupResult, setDupResult] = useState<DuplicateResponse | null>(null);
  const [dupLoading, setDupLoading] = useState(false);

  const stateVillages = villages.filter(v => !selectedState || selectedState === "All States" || v.state === selectedState);

  async function allocate() {
    setAllocLoading(true);
    setAllocResult(null);
    try {
      const r = await apiPost<{ recommended_village: string; reason: string; priority_score_calculated: number; priority_breakdown: PriorityBreakdown }>(`${apiBase}/allocate`, { resource, quantity: qty });
      setAllocResult(r);
      onAction();
    } finally {
      setAllocLoading(false);
    }
  }

  async function checkDuplicate() {
    setDupLoading(true);
    setDupResult(null);
    try {
      const r = await apiPost<DuplicateResponse>(`${apiBase}/duplicate-check`, { village: dupVillage, resource: dupResource });
      setDupResult(r);
    } finally {
      setDupLoading(false);
    }
  }

  const [selectedVillage, setSelectedVillage] = useState("");

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-[hsl(214,32%,91%)]">
        <div className="flex items-center gap-2">
          <div className="bg-[hsl(238,100%,96%)] p-2 rounded-lg">
            <Layers size={16} className="text-[hsl(238,83%,57%)]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">AI Optimization Engine</h3>
            <p className="text-[10px] text-[hsl(215,16%,47%)]">Smart resource allocation & duplicate detection</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-5">
        {/* State Filter */}
        <div className="lg:col-span-2">
          <label className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider mb-1 block">Filter by State</label>
          <div className="flex flex-wrap gap-1.5">
            {STATES.slice(0, 8).map(s => (
              <button
                key={s}
                onClick={() => onStateChange(s === "All States" ? "" : s)}
                className={`px-2.5 py-1 text-[10px] font-semibold rounded-full border transition-colors ${
                  (s === "All States" && !selectedState) || s === selectedState
                    ? "bg-[hsl(222,47%,11%)] text-white border-[hsl(222,47%,11%)]"
                    : "bg-white text-[hsl(215,16%,47%)] border-[hsl(214,32%,91%)] hover:bg-[hsl(210,40%,96%)]"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* AI Allocator */}
        <div className="flex flex-col gap-2">
          <div className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider">AI Resource Allocator</div>
          <select
            className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
            value={resource}
            onChange={(e) => setResource(e.target.value)}
          >
            <option>Food Kits</option>
            <option>Medicines</option>
            <option>Clean Water</option>
            <option>Shelter</option>
          </select>
          <input
            type="number"
            className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
            placeholder="Quantity"
            value={qty}
            min={1}
            onChange={(e) => setQty(parseInt(e.target.value) || 1)}
          />
          <button
            className="w-full bg-[hsl(238,83%,57%)] text-white text-xs font-semibold py-2.5 rounded-lg hover:opacity-90 transition-opacity"
            onClick={allocate}
            disabled={allocLoading}
          >
            {allocLoading ? "Optimizing..." : "Run AI Allocation"}
          </button>
          {allocResult && (
            <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 text-xs">
              <div className="font-bold text-blue-800 mb-1">{allocResult.recommended_village}</div>
              <div className="text-blue-700 text-[10px] leading-relaxed">{allocResult.reason}</div>
              <div className="mt-1.5 text-[10px] font-bold text-blue-600">Priority Score: {allocResult.priority_score_calculated}</div>
            </div>
          )}
        </div>

        {/* Duplicate Detection */}
        <div className="flex flex-col gap-2">
          <div className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wider">Duplicate Detection</div>
          <select
            className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
            value={selectedState}
            onChange={(e) => onStateChange(e.target.value)}
          >
            {STATES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <select
            className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
            value={selectedVillage}
            onChange={(e) => { setSelectedVillage(e.target.value); setDupVillage(e.target.value); }}
          >
            <option value="">Select Village...</option>
            {stateVillages.map((v) => (
              <option key={v.id} value={v.id}>{v.name}</option>
            ))}
          </select>
          <select
            className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
            value={dupResource}
            onChange={(e) => setDupResource(e.target.value)}
          >
            <option>Food Kits</option>
            <option>Medicines</option>
            <option>Clean Water</option>
            <option>Shelter</option>
          </select>
          <button
            className="w-full bg-[hsl(222,47%,11%)] text-white text-xs font-semibold py-2.5 rounded-lg hover:bg-[hsl(222,47%,8%)] transition-colors"
            onClick={checkDuplicate}
            disabled={dupLoading}
          >
            {dupLoading ? "Analyzing..." : "Analyze Cargo Drop Integrity"}
          </button>
          {dupResult && (
            <div className={`rounded-lg text-xs border ${dupResult.duplicate ? "bg-red-50 border-red-200" : "bg-emerald-50 border-emerald-200"}`}>
              <div className="px-3 py-2">
                <div className={`font-bold mb-1 ${dupResult.duplicate ? "text-red-800" : "text-emerald-800"}`}>
                  {dupResult.duplicate ? "Conflict Detected" : "Clear for Deployment"}
                </div>
                <div className={`text-[10px] ${dupResult.duplicate ? "text-red-700" : "text-emerald-700"}`}>{dupResult.message}</div>
                {dupResult.suggested_village && (
                  <div className={`mt-1 text-[10px] font-semibold ${dupResult.duplicate ? "text-red-700" : "text-emerald-700"}`}>
                    Redirect: {dupResult.suggested_village}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── SOS Panel ─────────────────────────────────────────────────────────
function SosPanel({ onSuccess, apiBase = "" }: { onSuccess: () => void; apiBase?: string }) {
  const [village, setVillage] = useState("");
  const [resource, setResource] = useState("Food Kits");
  const [families, setFamilies] = useState("");
  const [priority, setPriority] = useState("CRITICAL");
  const [result, setResult] = useState<SosResponse | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      const r = await apiPost<SosResponse>(`${apiBase}/sos`, {
        village,
        resource,
        families: parseInt(families),
        priority,
        lat: 13.0,
        lng: 80.0,
        severity_indicator: 35,
        crowd_verification_count: 1,
      });
      setResult(r);
      onSuccess();
      setVillage("");
      setFamilies("");
    } catch (e) {
      setResult({
        success: false,
        message: "Submission failed",
        inserted_id: "",
        calculated_priority: "",
        priority_breakdown: {
          geographical_score: 0, volunteer_report_score: 0,
          ngo_report_score: 0, crowd_verification_score: 0,
          disaster_severity_score: 0, previous_aid_impact: 0,
          final_priority_score: 0, classification: "unknown",
        }
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">SOS Registration Portal</h3>
      <p className="text-xs text-[hsl(215,16%,47%)] mb-4">Broadcast critical relief requests</p>
      <form className="flex flex-col gap-2" onSubmit={submit}>
        <input
          className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
          placeholder="Village Name"
          value={village}
          onChange={(e) => setVillage(e.target.value)}
          required
        />
        <select
          className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
          value={resource}
          onChange={(e) => setResource(e.target.value)}
        >
          <option>Food Supply Kits</option>
          <option>Clean Water</option>
          <option>Medicine & Medical</option>
          <option>Temporary Shelter</option>
        </select>
        <input
          className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
          placeholder="Families Affected"
          type="number"
          min={1}
          value={families}
          onChange={(e) => setFamilies(e.target.value)}
          required
        />
        <select
          className="w-full bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
        >
          <option value="CRITICAL">Emergency: Critical</option>
          <option value="STABLE">Emergency: Stable</option>
        </select>
        <button
          type="submit"
          className="w-full bg-[hsl(142,76%,36%)] text-white text-xs font-semibold py-2.5 rounded-lg hover:opacity-90 transition-opacity shadow-sm"
          disabled={loading}
        >
          {loading ? "Submitting..." : "Broadcast Emergency Request"}
        </button>
      </form>
      {result && (
        <div className={`mt-2 rounded-lg text-xs leading-relaxed overflow-hidden border ${
          result.success ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"
        }`}>
          <div className={`px-3 py-2 ${result.success ? "text-emerald-800" : "text-red-800"}`}>
            {result.success
              ? `${result.message} Priority: ${result.calculated_priority.toUpperCase()}`
              : result.message}
          </div>
          {result.success && result.priority_breakdown && (
            <div className="px-3 pb-2 pt-1 border-t border-emerald-200/50 bg-emerald-100/50">
              <div className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider mb-1">Priority Engine Score</div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-emerald-700">
                <div>Geo: {result.priority_breakdown.geographical_score.toFixed(1)}</div>
                <div>Volunteer: {result.priority_breakdown.volunteer_report_score.toFixed(1)}</div>
                <div>NGO: {result.priority_breakdown.ngo_report_score.toFixed(1)}</div>
                <div>Crowd: {result.priority_breakdown.crowd_verification_score.toFixed(1)}</div>
                <div>Severity: {result.priority_breakdown.disaster_severity_score.toFixed(1)}</div>
                <div>Aid Impact: {result.priority_breakdown.previous_aid_impact.toFixed(1)}</div>
                <div className="font-bold col-span-2">Final: {result.priority_breakdown.final_priority_score} → {result.priority_breakdown.classification.toUpperCase()}</div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Chat Panel ─────────────────────────────────────────────────────────
function ChatPanel({ apiBase = "" }: { apiBase?: string }) {
  const [messages, setMessages] = useState<{ role: "user" | "ai"; text: string }[]>([
    { role: "ai", text: "ReliefHub AI online. Ask about priorities, routes, or duplicates." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(msg?: string) {
    const text = msg || input.trim();
    if (!text) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text }]);
    setLoading(true);
    try {
      const r = await apiPost<ChatResponse>(`${apiBase}/chat`, { message: text });
      setMessages((m) => [...m, { role: "ai", text: r.response }]);
    } catch (e) {
      setMessages((m) => [...m, { role: "ai", text: "AI unavailable. Please retry." }]);
    } finally {
      setLoading(false);
    }
  }

  const chips = [
    "Which village needs urgent help?",
    "Where should I send food kits?",
    "Check for duplicate supplies",
    "What is the priority score breakdown?",
  ];

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">AI Cognitive Copilot</h3>
      <p className="text-xs text-[hsl(215,16%,47%)] mb-3">Natural language relief intelligence</p>
      <div className="h-[150px] overflow-y-auto bg-[hsl(40,33%,98%)] border border-[hsl(214,32%,91%)] rounded-lg p-3 flex flex-col gap-2">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`max-w-[88%] px-3 py-2 rounded-lg text-xs leading-relaxed whitespace-pre-line ${
              m.role === "user"
                ? "bg-[hsl(142,76%,93%)] text-[hsl(142,76%,20%)] self-end"
                : "bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] self-start border-l-[3px] border-l-blue-500"
            }`}
          >
            {m.text}
          </div>
        ))}
        {loading && (
          <div className="bg-white border border-[hsl(214,32%,91%)] text-[hsl(215,16%,47%)] self-start px-3 py-2 rounded-lg text-xs">
            ...
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="flex flex-wrap gap-1.5 mt-2">
        {chips.map((c) => (
          <button
            key={c}
            className="bg-white border border-[hsl(214,32%,91%)] text-[hsl(215,16%,47%)] px-3 py-1 text-[10px] font-medium rounded-full hover:bg-[hsl(210,40%,96%)] transition-colors"
            onClick={() => send(c)}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="flex gap-2 mt-2">
        <input
          className="flex-1 bg-white border border-[hsl(214,32%,91%)] text-[hsl(222,47%,11%)] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-[hsl(142,76%,36%)]"
          placeholder="Ask the AI copilot..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <button
          className="bg-[hsl(142,76%,36%)] text-white px-3 py-2 text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity"
          onClick={() => send()}
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  );
}

// ── Activity Feed Panel ──────────────────────────────────────────────
function ActivityFeed({ activities }: { activities: ActivityItem[] }) {
  const actorIcons: Record<string, React.ReactNode> = {
    "SOS Portal": <AlertTriangle size={12} className="text-red-500" />,
    "Priority Engine": <BarChart3 size={12} className="text-blue-500" />,
    "NGO Alpha": <Users size={12} className="text-emerald-500" />,
    "NGO Beta": <Users size={12} className="text-emerald-500" />,
    "Volunteer Report": <Shield size={12} className="text-amber-500" />,
    "AI Allocation Engine": <Layers size={12} className="text-violet-500" />,
    "Duplicate Detection": <AlertOctagon size={12} className="text-red-500" />,
    "ReliefHub System": <Radio size={12} className="text-slate-500" />,
  };

  return (
    <div className="bg-white rounded-xl border border-[hsl(214,32%,91%)] p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="bg-[hsl(210,40%,96%)] p-2 rounded-lg">
            <Activity size={16} className="text-[hsl(222,47%,11%)]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[hsl(222,47%,11%)]">NGO Activity Feed</h3>
            <p className="text-[10px] text-[hsl(215,16%,47%)]">Live activity timeline</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-[hsl(210,40%,96%)] px-2 py-1 rounded-full">
          <div className="w-1.5 h-1.5 rounded-full bg-[hsl(142,76%,36%)] animate-pulse" />
          <span className="text-[10px] font-semibold text-[hsl(215,16%,47%)]">Live</span>
        </div>
      </div>
      <div className="flex flex-col gap-2 max-h-[300px] overflow-y-auto">
        {activities.length === 0 ? (
          <div className="text-xs text-[hsl(215,16%,47%)] text-center py-4">No activities yet</div>
        ) : (
          activities.map((a, i) => (
            <div key={i} className="flex gap-2.5 items-start p-2.5 rounded-lg hover:bg-[hsl(210,40%,98%)] transition-colors border border-transparent hover:border-[hsl(214,32%,91%)]">
              <div className="mt-0.5 shrink-0 w-6 h-6 rounded-full bg-[hsl(210,40%,96%)] flex items-center justify-center">
                {actorIcons[a.actor] || <Clock size={12} className="text-[hsl(215,16%,47%)]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[10px] font-bold text-[hsl(222,47%,11%)]">{a.actor}</span>
                  <span className="text-[10px] text-[hsl(215,16%,47%)]">· {a.timestamp.split(" ")[1] || a.timestamp}</span>
                </div>
                <div className="text-[10px] font-semibold text-[hsl(142,76%,36%)] mb-0.5">{a.action}</div>
                <div className="text-[10px] text-[hsl(215,16%,47%)] leading-relaxed">{a.details}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ── Simulation Control Panel ────────────────────────────────────────────
const SCENARIOS = [
  { key: "cascade", label: "Multi-State Cascade", icon: "🌊", desc: "Flood + Cyclone + Landslide" },
  { key: "earthquake", label: "Earthquake Response", icon: "🏚️", desc: "Gujarat Seismic Zone" },
  { key: "drought", label: "Drought & Famine", icon: "☀️", desc: "Rajasthan Crisis" },
];

const QUICK_EVENTS = [
  { label: "Flood Zone", icon: "🌊", resource: "Emergency Food Kits", severity: 88,
    lat: 25.6, lng: 85.1, state: "Bihar", families: 320 },
  { label: "Cyclone Hit", icon: "🌀", resource: "Temporary Shelter", severity: 85,
    lat: 15.3, lng: 80.0, state: "Andhra Pradesh", families: 265 },
  { label: "Earthquake", icon: "🏚️", resource: "Medical Aid", severity: 92,
    lat: 23.2, lng: 77.4, state: "Madhya Pradesh", families: 410 },
  { label: "Heatwave", icon: "🔥", resource: "Food Grains & Water", severity: 60,
    lat: 28.7, lng: 77.1, state: "Delhi", families: 150 },
];

function SimulationControlPanel({ base, onRefresh }: { base: string; onRefresh: () => void }) {
  const [scenario, setScenario] = useState("cascade");
  const [switching, setSwitching] = useState(false);
  const [injecting, setInjecting] = useState<string | null>(null);
  const [lastAction, setLastAction] = useState<string | null>(null);

  async function handleScenarioSwitch(key: string) {
    if (key === scenario) return;
    setSwitching(true);
    setLastAction(null);
    try {
      await apiPost(`${base}/switch-scenario`, { scenario: key });
      setScenario(key);
      setLastAction(`Switched to ${SCENARIOS.find(s => s.key === key)?.label}`);
      onRefresh();
    } finally {
      setSwitching(false);
    }
  }

  async function handleReset() {
    setSwitching(true);
    setLastAction(null);
    try {
      await apiPost(`${base}/reset`, {});
      setScenario("cascade");
      setLastAction("Scenario reset to Multi-State Cascade");
      onRefresh();
    } finally {
      setSwitching(false);
    }
  }

  async function handleInject(ev: typeof QUICK_EVENTS[0]) {
    setInjecting(ev.label);
    try {
      await apiPost(`${base}/sos`, {
        village: ev.label,
        resource: ev.resource,
        families: ev.families,
        severity_indicator: ev.severity,
        crowd_verification_count: 4,
        lat: ev.lat,
        lng: ev.lng,
        state: ev.state,
      });
      setLastAction(`Injected: ${ev.icon} ${ev.label}`);
      onRefresh();
    } finally {
      setInjecting(null);
    }
  }

  const active = SCENARIOS.find(s => s.key === scenario)!;

  return (
    <div className="flex flex-col gap-2">
      <div className="bg-red-600 text-white rounded-xl px-5 py-3 flex items-center gap-3 shadow-md">
        <FlaskConical size={18} className="shrink-0" />
        <div>
          <div className="text-sm font-bold">SIMULATION MODE — Disaster Scenario Active</div>
          <div className="text-[11px] text-red-100">
            {active.icon} {active.desc} — All data is simulated for demonstration purposes
          </div>
        </div>
        <div className="ml-auto bg-red-700 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0">
          DEMO ONLY
        </div>
      </div>

      <div className="bg-white border border-[hsl(214,32%,91%)] rounded-xl px-4 py-3 flex flex-wrap items-center gap-3 shadow-sm">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wide">Scenario</span>
          <div className="flex gap-1">
            {SCENARIOS.map(s => (
              <button
                key={s.key}
                onClick={() => handleScenarioSwitch(s.key)}
                disabled={switching}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                  scenario === s.key
                    ? "bg-[hsl(222,47%,11%)] text-white"
                    : "bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)] hover:bg-[hsl(210,40%,92%)]"
                } disabled:opacity-50`}
              >
                {s.icon} {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="h-6 w-px bg-[hsl(214,32%,91%)]" />

        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[10px] font-bold text-[hsl(215,16%,47%)] uppercase tracking-wide">Inject Event</span>
          {QUICK_EVENTS.map(ev => (
            <button
              key={ev.label}
              onClick={() => handleInject(ev)}
              disabled={!!injecting}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-orange-50 text-orange-700 border border-orange-200 hover:bg-orange-100 transition-all disabled:opacity-50"
            >
              {injecting === ev.label ? "..." : `${ev.icon} ${ev.label}`}
            </button>
          ))}
        </div>

        <div className="h-6 w-px bg-[hsl(214,32%,91%)]" />

        <button
          onClick={handleReset}
          disabled={switching}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 transition-all disabled:opacity-50 ml-auto"
        >
          <RefreshCcw size={12} />
          {switching ? "Resetting..." : "Reset Scenario"}
        </button>

        {lastAction && (
          <span className="text-[10px] text-[hsl(142,76%,36%)] font-semibold ml-1">{lastAction}</span>
        )}
      </div>
    </div>
  );
}

function Dashboard({ mode = "live" }: { mode?: "live" | "testing" }) {
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [villages, setVillages] = useState<Village[]>([]);
  const [supply, setSupply] = useState<SupplyData | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [ticker, setTicker] = useState("ReliefHub coordination matrix online — all systems operational.");
  const [selectedVillage, setSelectedVillage] = useState<Village | null>(null);
  const [selectedState, setSelectedState] = useState<string>("");

  const [sosModalOpen, setSosModalOpen] = useState(false);
  const [sosGeoStatus, setSosGeoStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");
  const [sosGeoPos, setSosGeoPos] = useState<{ lat: number; lng: number } | null>(null);
  const [sosSubmitting, setSosSubmitting] = useState(false);
  const [sosToast, setSosToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [sosMarkersList, setSosMarkersList] = useState<SosMarker[]>([]);

  const base = mode === "testing" ? "/api/v1/testing" : "/api/v1";

  async function loadAll() {
    setLoading(true);
    try {
      const [d, rawVillages, s, a, act] = await Promise.all([
        fetch(`${base}/dashboard`).then(r => r.json()) as Promise<DashboardData>,
        mode === "testing"
          ? fetch(`${base}/villages`).then(r => r.json()) as Promise<TestingVillagesResponse>
          : fetch(`${base}/villages`).then(r => r.json()) as Promise<Village[]>,
        fetch(`${base}/supply-tracking`).then(r => r.json()) as Promise<SupplyData>,
        fetch(`${base}/analytics`).then(r => r.json()) as Promise<AnalyticsData>,
        fetch(`${base}/activities`).then(r => r.json()) as Promise<ActivitiesResponse>,
      ]);
      const v = mode === "testing"
        ? (rawVillages as TestingVillagesResponse).villages
        : (rawVillages as Village[]);
      setDashboard(d);
      setVillages(v);
      setSupply(s);
      setAnalytics(a);
      setActivities(act.activities);
      const crit = v.filter((x) => x.status === "critical").length;
      setTicker(`${v.length} village sectors monitored. ${crit} critical. Priority Engine active.`);
    } catch (e) {
      console.error(e);
      setTicker("Error loading data. Please retry.");
    } finally {
      setLoading(false);
    }
  }

  function showToast(msg: string, ok: boolean) {
    setSosToast({ msg, ok });
    setTimeout(() => setSosToast(null), 4000);
  }

  function openSosEmergency() {
    setSosModalOpen(true);
    setSosGeoStatus("requesting");
    setSosGeoPos(null);
    if (!navigator.geolocation) {
      setSosGeoStatus("denied");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setSosGeoPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setSosGeoStatus("granted");
      },
      () => setSosGeoStatus("denied"),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  async function submitSosEmergency() {
    if (!sosGeoPos) return;
    setSosSubmitting(true);
    try {
      const ts = new Date().toLocaleTimeString();
      const r = await apiPost<SosResponse>(`/api/v1/sos`, {
        village: "Field Responder",
        resource: "Emergency Response",
        families: 50,
        priority: "CRITICAL",
        lat: sosGeoPos.lat,
        lng: sosGeoPos.lng,
        severity_indicator: 88,
        crowd_verification_count: 4,
        state: "Field",
      });
      const marker: SosMarker = {
        id: r.inserted_id,
        lat: sosGeoPos.lat,
        lng: sosGeoPos.lng,
        village: "Field Responder",
        timestamp: ts,
        families: 50,
      };
      setSosMarkersList((prev) => [...prev, marker]);
      setSosModalOpen(false);
      setSosGeoStatus("idle");
      loadAll();
      showToast(`SOS transmitted! Priority: ${r.calculated_priority.toUpperCase()} · Score: ${r.priority_breakdown.final_priority_score}`, true);
    } catch {
      showToast("SOS transmission failed. Check connection.", false);
    } finally {
      setSosSubmitting(false);
    }
  }

  useEffect(() => {
    loadAll();
    const interval = setInterval(loadAll, 10000);
    return () => clearInterval(interval);
  }, []);

  const topVillage = villages.length > 0
    ? villages.reduce((a, b) =>
        a.priority_breakdown.final_priority_score >= b.priority_breakdown.final_priority_score ? a : b
      )
    : null;
  const displayVillage = selectedVillage ?? topVillage;
  const isDefaultVillage = !selectedVillage && !!topVillage;

  return (
    <div className="min-h-screen overflow-x-hidden bg-[hsl(210,40%,98%)] p-4 lg:p-6 flex flex-col gap-4">
      {mode === "testing" && (
        <SimulationControlPanel base="/api/v1" onRefresh={loadAll} />
      )}

      {sosToast && (
        <div className={`fixed top-16 right-4 z-[10000] flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold transition-all animate-fade-in ${
          sosToast.ok ? "bg-emerald-600 text-white" : "bg-red-600 text-white"
        }`}>
          {sosToast.ok ? <Bell size={16} /> : <AlertTriangle size={16} />}
          {sosToast.msg}
        </div>
      )}

      {sosModalOpen && (
        <div className="fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-red-100 p-3 rounded-xl">
                <Zap size={22} className="text-red-600" />
              </div>
              <div>
                <div className="text-base font-bold text-[hsl(222,47%,11%)]">Emergency SOS</div>
                <div className="text-[11px] text-[hsl(215,16%,47%)]">Transmit your GPS location to dispatch</div>
              </div>
              <button
                className="ml-auto p-1.5 hover:bg-[hsl(210,40%,96%)] rounded-lg"
                onClick={() => { setSosModalOpen(false); setSosGeoStatus("idle"); }}
              >
                <X size={16} className="text-[hsl(215,16%,47%)]" />
              </button>
            </div>

            {sosGeoStatus === "requesting" && (
              <div className="flex flex-col items-center py-6 gap-3">
                <div className="w-10 h-10 rounded-full border-4 border-red-500 border-t-transparent animate-spin" />
                <p className="text-sm text-[hsl(215,16%,47%)]">Acquiring GPS location...</p>
                <p className="text-[10px] text-[hsl(215,16%,47%)]">Please allow location access when prompted</p>
              </div>
            )}

            {sosGeoStatus === "denied" && (
              <div className="flex flex-col items-center py-4 gap-3 text-center">
                <div className="bg-red-100 p-3 rounded-full">
                  <MapPin size={24} className="text-red-500" />
                </div>
                <p className="text-sm font-semibold text-red-700">Location access denied</p>
                <p className="text-[11px] text-[hsl(215,16%,47%)] leading-relaxed">
                  Enable location in your browser settings, then try again.
                </p>
                <button
                  className="mt-1 w-full min-h-[44px] bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)] text-sm font-semibold py-2.5 rounded-xl"
                  onClick={() => { setSosModalOpen(false); setSosGeoStatus("idle"); }}
                >
                  Close
                </button>
              </div>
            )}

            {sosGeoStatus === "granted" && sosGeoPos && (
              <div className="flex flex-col gap-3">
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-start gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1 shrink-0 animate-pulse" />
                  <div>
                    <div className="text-[11px] font-bold text-emerald-700 mb-0.5">GPS Acquired</div>
                    <div className="text-[10px] text-emerald-600">{sosGeoPos.lat.toFixed(5)}°N, {sosGeoPos.lng.toFixed(5)}°E</div>
                  </div>
                </div>
                <p className="text-[11px] text-[hsl(215,16%,47%)] leading-relaxed">
                  Your coordinates will be transmitted to the ReliefHub coordination matrix.
                </p>
                <button
                  className="w-full min-h-[44px] bg-red-600 hover:bg-red-700 text-white text-sm font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-red-200"
                  onClick={submitSosEmergency}
                  disabled={sosSubmitting}
                >
                  {sosSubmitting ? (
                    <><div className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" /> Transmitting...</>
                  ) : (
                    <><Zap size={16} /> Transmit Emergency SOS</>
                  )}
                </button>
                <button
                  className="w-full min-h-[44px] bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)] text-sm font-semibold py-2.5 rounded-xl"
                  onClick={() => { setSosModalOpen(false); setSosGeoStatus("idle"); }}
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      <header className="bg-white border border-[hsl(214,32%,91%)] px-4 sm:px-5 py-3.5 rounded-2xl shadow-sm flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl ${mode === "testing" ? "bg-red-100" : "bg-[hsl(142,76%,93%)]"}`}>
            {mode === "testing"
              ? <FlaskConical size={22} className="text-red-600" />
              : <Shield size={22} className="text-[hsl(142,76%,36%)]" />}
          </div>
          <div>
            <div className="text-lg font-bold text-[hsl(222,47%,11%)] tracking-tight">
              ReliefHub {mode === "testing" ? "— Simulation" : ""}
            </div>
            <div className="text-[11px] text-[hsl(215,16%,47%)]">
              {mode === "testing"
                ? "Disaster Scenario Testing Environment"
                : "AI-Powered Disaster Relief Coordination Platform"}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {mode === "live" && (
            <button
              onClick={openSosEmergency}
              className="flex items-center gap-1.5 min-h-[44px] px-3 sm:px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-[11px] sm:text-xs font-bold transition-colors shadow-md shadow-red-200"
            >
              <Zap size={14} className="shrink-0" />
              <span className="hidden sm:inline">91-SOS EMERGENCY</span>
              <span className="sm:hidden">SOS</span>
            </button>
          )}
          <div className={`hidden sm:flex items-center gap-2 px-3 py-2 rounded-full ${mode === "testing" ? "bg-red-50" : "bg-[hsl(210,40%,96%)]"}`}>
            <div className={`w-2 h-2 rounded-full animate-[pulse-ring_2s_infinite] ${mode === "testing" ? "bg-red-500" : "bg-[hsl(142,76%,36%)]"}`} />
            <span className="text-[11px] font-semibold text-[hsl(215,16%,47%)]">
              {mode === "testing" ? "Simulation Mode: Active" : "Live Regional Sync: Active"}
            </span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <KpiCard
          label="Villages Affected"
          value={dashboard?.villages_affected ?? "—"}
          icon={<MapPin size={16} />}
          accent="bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)]"
        />
        <KpiCard
          label="Families Helped"
          value={dashboard?.families_helped?.toLocaleString() ?? "—"}
          icon={<Users size={16} />}
          accent="bg-[hsl(142,76%,93%)] text-[hsl(142,76%,36%)]"
        />
        <KpiCard
          label="Active NGOs"
          value={dashboard?.active_ngos ?? "—"}
          icon={<TrendingUp size={16} />}
          accent="bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)]"
        />
        <KpiCard
          label="Relief Items Delivered"
          value={dashboard?.items_delivered?.toLocaleString() ?? "—"}
          icon={<Package size={16} />}
          accent="bg-[hsl(210,40%,96%)] text-[hsl(222,47%,11%)]"
        />
      </div>

      {analytics && (
        <div className="grid grid-cols-3 gap-3 sm:gap-4">
          <div className="bg-white rounded-xl border border-red-200 p-3 sm:p-4 shadow-sm flex items-center gap-2 sm:gap-3">
            <div className="bg-red-100 p-2 rounded-lg shrink-0"><AlertTriangle size={16} className="text-red-600" /></div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-red-700">{analytics.critical}</div>
              <div className="text-[9px] sm:text-[10px] font-semibold text-red-600 uppercase tracking-wider">Critical Villages</div>
            </div>
          </div>
          <div className="bg-white rounded-xl border border-amber-200 p-3 sm:p-4 shadow-sm flex items-center gap-2 sm:gap-3">
            <div className="bg-amber-100 p-2 rounded-lg shrink-0"><AlertOctagon size={16} className="text-amber-600" /></div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-amber-700">{analytics.moderate}</div>
              <div className="text-[9px] sm:text-[10px] font-semibold text-amber-600 uppercase tracking-wider">Moderate Villages</div>
            </div>
          </div>
          <div className="bg-white rounded-xl border border-emerald-200 p-3 sm:p-4 shadow-sm flex items-center gap-2 sm:gap-3">
            <div className="bg-emerald-100 p-2 rounded-lg shrink-0"><CircleCheck size={16} className="text-emerald-600" /></div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-emerald-700">{analytics.covered}</div>
              <div className="text-[9px] sm:text-[10px] font-semibold text-emerald-600 uppercase tracking-wider">Covered Villages</div>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-4 flex-1">
        <div className="flex-[1.2] flex flex-col gap-4">
          <MapPanel
            villages={villages}
            onVillageSelect={setSelectedVillage}
            selectedVillage={selectedVillage}
            selectedState={selectedState}
            sosMarkers={sosMarkersList}
          />
          <PriorityEnginePanel
            village={displayVillage}
            onClose={() => setSelectedVillage(null)}
            isDefault={isDefaultVillage}
          />
          <SupplyPanel supply={supply} />
        </div>

        <div className="flex-[1.5] flex flex-col gap-4">
          <AiPanel villages={villages} onAction={loadAll} selectedState={selectedState} onStateChange={setSelectedState} apiBase={mode === "testing" ? "/api/v1" : "/api/v1"} />
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <SosPanel onSuccess={loadAll} apiBase={mode === "testing" ? "/api/v1" : "/api/v1"} />
            </div>
            <div className="flex-1">
              <ChatPanel apiBase={mode === "testing" ? "/api/v1" : "/api/v1"} />
            </div>
          </div>
          <ActivityFeed activities={activities} />
        </div>
      </div>

      <footer className="bg-white border border-[hsl(214,32%,91%)] px-4 sm:px-5 py-2.5 rounded-xl shadow-sm flex items-center gap-3 text-[11px]">
        <span className="text-[hsl(142,76%,36%)] font-bold uppercase tracking-wider shrink-0">System Event</span>
        <span className="text-[hsl(215,16%,47%)] font-medium truncate">[{new Date().toLocaleTimeString()}] — {ticker}</span>
      </footer>
    </div>
  );
}

function AppInner() {
  const [splashDone, setSplashDone] = useState(false);
  const [langDone, setLangDone] = useState(
    () => !!localStorage.getItem("reliefhub_lang")
  );

  if (!splashDone) {
    return <SplashScreen onDone={() => setSplashDone(true)} />;
  }
  if (!langDone) {
    return <LanguageSelection onDone={() => setLangDone(true)} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <NavBar />
      <Routes>
        <RRRoute path="/testing" element={<Dashboard mode="testing" />} />
        <RRRoute path="/radar" element={<RadarPage />} />
        <RRRoute path="/dashboard" element={<Dashboard mode="live" />} />
        <RRRoute path="/help" element={<HelpFlow />} />
        <RRRoute path="/" element={<LandingPage />} />
      </Routes>
    </QueryClientProvider>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AppInner />
    </LanguageProvider>
  );
}

export default App;
