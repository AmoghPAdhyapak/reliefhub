# ReliefHub

AI-powered disaster relief coordination platform that connects citizens, NGOs, and responders for faster, smarter disaster response across India.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the FastAPI backend (port 5000, Python uvicorn)
- `pnpm --filter @workspace/reliefhub-web run dev` — run the React frontend (port from `$PORT`)
- Required env: none (runs self-contained with simulated data)

## Stack

- **Backend**: Python FastAPI + uvicorn, auto-reload in dev
- **Frontend**: React 19 + Vite + Tailwind CSS + react-leaflet v5 + react-router-dom v6
- **Languages**: 11 Indian languages via `LanguageContext` (en, hi, kn, ta, te, ml, bn, gu, mr, pa, ur)
- **Weather**: Open-Meteo free API (no key needed)

## Where things live

- `artifacts/api-server/main.py` — FastAPI backend; all routes at `/api/v1/*`
- `artifacts/reliefhub-web/src/App.tsx` — main app; `AppInner` handles splash→language→app flow
- `artifacts/reliefhub-web/src/context/LanguageContext.tsx` — all translations (11 languages, ~60 keys each)
- `artifacts/reliefhub-web/src/pages/RadarPage.tsx` — weather radar with Open-Meteo live data
- `artifacts/reliefhub-web/src/LandingPage.tsx` — homepage (route `/`)
- `artifacts/reliefhub-web/src/SplashScreen.tsx` — animated 2.6s splash
- `artifacts/reliefhub-web/src/LanguageSelection.tsx` — 11-language picker (skipped if `reliefhub_lang` in localStorage)
- `artifacts/reliefhub-web/src/pages/HelpFlow.tsx` — GET HELP flow (GPS or manual location)
- `artifacts/reliefhub-web/src/components/NavBar.tsx` — language selector (top-left) + View Live Demo button (top-right)

## Routes

| Path | Component | Notes |
|------|-----------|-------|
| `/` | LandingPage | Hero + 3 cards + workflow |
| `/dashboard` | Dashboard (live mode) | Live map, SOS, Priority Engine, AI Copilot |
| `/testing` | Dashboard (simulation mode) | Same as dashboard with sim banner |
| `/radar` | RadarPage | Animated radar + real weather from Open-Meteo |
| `/help` | HelpFlow | GPS/manual location → disaster check |

## Architecture decisions

- Language gate: splash (2.6s) → language selection → app. Skipped on repeat visits via `reliefhub_lang` localStorage key.
- All translations use a `t(key)` fallback to English if a key is missing in a language.
- RadarPage fetches live weather from Open-Meteo (free, no API key) — rainfall, wind speed, humidity, temperature for 8 major Indian cities.
- The `/api/v1/villages` endpoint starts empty; only real SOS submissions populate it (simulation data is generated in-memory by the backend).
- Backend is Python FastAPI served via uvicorn; frontend is React+Vite in a separate artifact; both are proxied through the shared Replit reverse proxy.

## Product

- **Citizens** use the GET HELP flow to report emergencies with GPS or manual location
- **NGOs / responders** use the Live Dashboard to see village needs, priority scores, supply tracking, and AI-optimized allocation
- **Coordinators** use the Simulation mode to run disaster scenario drills
- **Radar** page shows real-time weather threat levels across 8 Indian metros

## User preferences

_None yet._

## Gotchas

- Gujarati script has many zero-width combining characters — copy-paste from mixed sources can embed invisible bad chars that break the JS parser. Always verify Gujarati strings render correctly before committing.
- `pnpm run dev` at the workspace root doesn't work (no root dev script by design). Use `restart_workflow` to restart individual services.
- The Vite dev server must have `server.allowedHosts: true` (already set) for the Replit iframe proxy to work.
